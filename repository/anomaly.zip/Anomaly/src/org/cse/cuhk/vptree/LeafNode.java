package org.cse.cuhk.vptree;

import org.cse.cuhk.stream.application.Pivot;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class is of leaf nodes, where the pivots are stored
 */
public class LeafNode extends Node {

	/**
	 * the pivot indexed by the leaf node
	 */
	private Pivot[] pivots = null; // = new Pivot[10];

	/**
	 * construct the leaf node by a pivot array
	 * 
	 * @param p,
	 *            the pivot array stored in the leaf node
	 */
	public LeafNode(Pivot[] p) {
		super();
		pivots = p;
		int size = Integer.parseInt(System.getProperty("VPLeafSize"));
		if (p.length > size) {
			System.out.println("Leaf Size Overflow!!!!!!");
		}
	}

	/**
	 * The method is to return array of pivots indexed by this leaf node
	 * 
	 * @return the pivot array indexed by this array
	 */
	public Pivot[] getPivots() {
		return pivots;
	}
}
