package org.cse.cuhk.vptree;

import java.util.List;

import org.cse.cuhk.stream.application.Memory;
import org.cse.cuhk.stream.application.OutlierDetection;
import org.cse.cuhk.stream.application.Pivot;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * This class is of VP-tree indexing structure
 * 
 */
public class VPTree {

	/**
	 * the leaf size
	 */
	private int leafSize = 0;

	/**
	 * the root of VP-tree
	 */
	private Node root = null;

	/**
	 * the parent - OutlierDetection
	 */
	private OutlierDetection parent = null;

	// /**
	// * the k of k-d outlier definition
	// */
	// private int K = 0;

	/**
	 * the start poisition of subsequences indexed by this VP-tree
	 */
	private int start = 0;

	/**
	 * the ending position of subsequnces indexed by VP-tree
	 */
	private int end = 0;

	/**
	 * the pivots indexed by this VP-tree
	 */
	private Pivot[] pivots = null;

	/**
	 * the construct of VP-tree
	 */
	public VPTree(Pivot[] p, float[][] d) {
		leafSize = Integer.parseInt(System.getProperty("VPLeafSize"));
		if (p.length > 0) {
			/**
			 * set the start position of VP-tree
			 */
			start = p[0].getPoint();
			/**
			 * set the end position of VP-tree
			 */
			end = p[p.length - 1].getPoint();

			/**
			 * set the pivot array to be p
			 */
			pivots = p;
		}
		/**
		 * construct the VP-tree
		 */
		root = constructTree(d, p);
		/**
		 * set the k of k-d outlier definition
		 */
		// K = Integer.parseInt(System.getProperty("K"));
	}

	/**
	 * return the start position indexed by this VP-tree
	 * 
	 * @return the start position indexed by this VP-tree
	 */
	public int getStart() {
		return start;
	}

	/**
	 * return the ending position indexed by this VP-tree
	 * 
	 * @return the ending position indexed by this VP-tree
	 */
	public int getEnd() {
		return end;
	}

	/**
	 * the empty constructor of this VP-tree
	 * 
	 */
	public VPTree() {

	}

	/**
	 * Set the parent OutlierDetection object of this tree
	 * 
	 * @param p
	 *            the pointer to OutlierDetection object
	 */
	public void setParent(OutlierDetection p) {
		parent = p;
	}

	/**
	 * execute a range query of on a vantage pivot
	 * 
	 * @param range
	 * @param queryPoint
	 */
	public void query(float range, Pivot queryPoint) {

		query(root, range, queryPoint);
	}

	/**
	 * for every tree, search the whole tree unless pivot's 1/2*range nearest
	 * neighbor number is already larger than k
	 * 
	 * @param r
	 * @param range
	 * @param queryPoint
	 */
	private void query(Node r, float range, Pivot queryPoint) {
		/**
		 * if the pivot and its nearest neighbors could not be outliers return
		 */
		// if (queryPoint.get_num_half_range_neighbors() >= K) {
		// return;
		// }
		if (parent.isStop(queryPoint))
			return;
		/**
		 * if r == null return
		 */
		/**
		 * if r is an instance of leaf node squential scan on the leaf nodes
		 */
		if (r instanceof LeafNode) {
			/**
			 * sequential scan in leaf node
			 */
			Pivot[] pivots = ((LeafNode) r).getPivots();
			for (int i = 0; i < pivots.length; i++) {
				// if (pivots[i] != null) {
				/**
				 * calculate the Lp-2 distance with each pivot
				 */
				// float dist = parent.distance_Lp_2(pivots[i].getPoint(),
				// queryPoint.getPoint());
				/**
				 * see if distance less than the range if yes, join the two
				 * pivots 2e-query
				 */
				Memory.joinPivots(queryPoint, pivots[i], parent
						.getSlidingWindowEnd(), parent.getRange());
				// if (pivots[i].get_num_half_range_neighbors() >= K)
				// return;
				// /**
				// * see if distance less than 1/2*e if yes join the pivots
				// */
				// if (dist < 0.25 * range) {
				// /**
				// * increase the pivot's hal_range_number
				// */
				// queryPoint.increase_half_range_neighbors();
				// if (queryPoint.get_num_half_range_neighbors() > k) {
				// return;
				// }
				// }
				// }
			}
		} else {
			/**
			 * if r is not leaf node, go into its child or children
			 * 
			 */
			/**
			 * search in the internal node
			 */
			Pivot pivot = r.getPivot();
			// if (Math
			// .abs(parent.getSlidingWindowEnd() - r.getPivot().getPoint()) >
			// Memory.memoryForWindow
			// - Memory.memoryForTree) {
			//
			// Memory.IOcost++;
			//			}
			// if(pivot ==null)
			// System.out.println("the pivot in Node is null!!!");
			/**
			 * the distance between vantage pivot and query point
			 */
			// if(parent != null)
			// System.out.println("Parent is not null!!!!!");
			float dist = Memory.distance_Lp_2(pivot.getPoint(), queryPoint
					.getPoint());
			/**
			 * go to left child
			 */
			if (dist < r.getPartitionDistance() - range) {
				// go to the left child of current node
				query(r.getLeftChild(), range, queryPoint);
			} else if (dist > r.getPartitionDistance() + range) {
				// go to right child of current node
				query(r.getRightChild(), range, queryPoint);
			} else {
				// go to both children the current node
				/**
				 * go to both children
				 */
				query(r.getLeftChild(), range, queryPoint);
				query(r.getRightChild(), range, queryPoint);
			}
		}

	}

	/**
	 * construct a VP-tree from scratch
	 * 
	 * @param distances
	 *            the partition distance
	 * @param pivots
	 *            the pivots to be indexed
	 * 
	 * @return the node object which is root
	 */
	private Node constructTree(float distances[][], Pivot pivots[]) {
		/**
		 * distance might be not full
		 */
		if (pivots.length < 1)
			return null;

		if (pivots.length <= leafSize)
			return new LeafNode(pivots);

		/**
		 * select a vantage point
		 */
		int vantage = selectVantage(distances);

		if (pivots[vantage] == null) {
			System.out.println("Node pivot is null!!");
			System.out.println("the " + vantage + " entry!!");
			Memory.log.println("the " + vantage + " entry!!");
			Memory.log.flush();
		}
		/**
		 * set root's pivot to be the pivot array
		 */
		Node r = new Node(pivots[vantage]);

		/**
		 * set the result to be the sorted array of distances
		 */
		float[] result = QuickSort.quicksort(distances[vantage]);

		/**
		 * set middle to zero
		 */
		int middle = 0;
		if (result.length % 2 == 0)
			middle = result.length / 2 - 1;
		else
			middle = result.length / 2;
		// move middle to right if equal value appears
		while (middle + 1 < result.length
				&& result[middle] == result[middle + 1]) {
			middle++;
			//System.out.println("some distance are equal!!");
			//Memory.log.println("some distance are equal!!");
		}

		float partition_distance = result[middle];
		// System.out.println(partition_distance);
		/**
		 * set r's partition distance
		 */
		r.setPartitionDistance(partition_distance);

		/**
		 * the number of right pivots is not affected by original size
		 */
		Pivot[] rightPivots = new Pivot[result.length - middle - 1];
		int[] rightPointers = new int[result.length - middle - 1]; // pointer
		// to
		// original pivots

		Pivot[] leftPivots;

		/**
		 * the number of left pivots = middle + 1
		 */
		leftPivots = new Pivot[middle + 1];
		int[] leftPointers = new int[middle + 1]; // pointer to
		// original

		float[][] leftDistances = new float[leftPivots.length][leftPivots.length];
		float[][] rightDistances = new float[rightPivots.length][rightPivots.length];

		int number_left = 0;
		int number_right = 0;

		/**
		 * partition the data points to 2 groups
		 */
		for (int i = 0; i < pivots.length; i++) {
			/**
			 * assign to the left part
			 */
			if (distances[vantage][i] <= partition_distance) {
				leftPivots[number_left] = pivots[i];
				leftPointers[number_left] = i;
				number_left++;
			} else {
				/**
				 * assign to the right part
				 */
				rightPivots[number_right] = pivots[i];
				rightPointers[number_right] = i;
				number_right++;
			}
		}
		if (number_left != number_right) {
			//System.out
			//		.println("the left number is not equal to the right number");
			//System.out.println(number_left + " " + number_right + " "
			//		+ pivots.length);
			//System.out.println(leftPivots.length + " " + rightPivots.length
			//		+ " " + middle);
			Memory.log
					.println("the left number is not equal to the right number");
			Memory.log.println(number_left + " " + number_right + " "
					+ pivots.length);
			Memory.log.println(leftPivots.length + " " + rightPivots.length
					+ " " + middle);
		}
		/**
		 * check if there is some point missed in previous procedure
		 */
		if (number_left + number_right != pivots.length) {
			System.out.println("VP-tree partition error!");
			Memory.log.println("VP-tree partition error!");
		}
		Memory.log.flush();

		for (int i = 0; i < leftPivots.length; i++)
			for (int j = 0; j < leftPivots.length; j++) {
				leftDistances[i][j] = distances[leftPointers[i]][leftPointers[j]];
			}
		for (int i = 0; i < rightPivots.length; i++)
			for (int j = 0; j < rightPivots.length; j++) {
				rightDistances[i][j] = distances[rightPointers[i]][rightPointers[j]];
			}
		r.setChildren(constructTree(leftDistances, leftPivots), constructTree(
				rightDistances, rightPivots));
		return r;
	}

	/**
	 * return which pivot is selected as vantage point
	 * 
	 * @param distances
	 * @return
	 */
	private int selectVantage(float[][] distances) {
		float max = 0;
		float current = 0;
		int vantage_so_far = 0;

		for (int i = 0; i < distances.length; i++) {
			current = standardDeviation(distances[i], i);
			// System.out.println(current);
			if (current > max) {
				max = current;
				vantage_so_far = i;
			}
		}
		return vantage_so_far;
	}

	/**
	 * calculate standard deviation
	 * 
	 * @param data
	 * @param row
	 * @return
	 */
	private float standardDeviation(float[] data, int row) {
		float mean = 0;
		for (int i = 0; i < data.length; i++) {
			mean = mean + data[i];
		}
		mean = mean / (data.length - 1);
		float SD = 0;
		for (int i = 0; i < data.length; i++) {
			if (i != row) {
				// accumulate the standard derivation
				SD = SD + (data[i] - mean) * (data[i] - mean);
			}
		}
		SD = (float) Math.sqrt((double) SD);
		return SD;
	}

	/**
	 * return the root object
	 * 
	 * @return the root object
	 */
	public Node getRoot() {
		return root;
	}

	/**
	 * return the pivot array
	 * 
	 * @return the pivot array indexed by this VP-tree
	 */
	public Pivot[] getPivots() {
		return pivots;
	}

	/**
	 * set the position of start pivot
	 * 
	 * @param s
	 *            the poisition of the start pivot
	 */
	public void setStart(int s) {
		start = s;
	}

	/**
	 * set the position of ending pivot
	 * 
	 * @param e
	 *            the position of the ending pivot
	 */
	public void setEnd(int e) {
		end = e;
	}

	public void checkPivots() {
		// if (getPivotCount(this.root) != this.pivots.length) {
		// Memory.log.println("VPTree bug");
		// } else {
		// Memory.log.println("VPTree is right");
		// }
		// Memory.log.flush();
		// boolean right = true;
		// for (int i = 0; i < pivots.length; i++) {
		// if (!isIn(pivots[i])) {
		// Memory.log.println("VPTree bug pivot " + i + " lost!");
		// right = false;
		// }
		// }
		// Memory.log.println("VPTree's pivots are " + right);
		// Memory.log.flush();
	}

	public boolean isIn(Pivot p) {
		return inNode(root, p);
	}

	public boolean inNode(Node node, Pivot p) {
		if (node instanceof LeafNode) {
			/**
			 * sequential scan in leaf node
			 */
			Pivot[] pivs = ((LeafNode) node).getPivots();
			for (int i = 0; i < pivs.length; i++) {
				if (pivs[i] == p)
					return true;
			}
		} else {
			if (inNode(node.getLeftChild(), p))
				return true;
			if (inNode(node.getRightChild(), p))
				return true;
		}
		return false;
	}

	public int getPivotCount(Node node) {
		/**
		 * if r is an instance of leaf node squential scan on the leaf nodes
		 */
		if (node instanceof LeafNode) {
			/**
			 * sequential scan in leaf node
			 */
			Pivot[] pivs = ((LeafNode) node).getPivots();
			return pivs.length;
		} else {
			return getPivotCount(node.getLeftChild())
					+ getPivotCount(node.getRightChild());
		}
	}

	/**
	 * execute a range query of on a vantage pivot
	 * 
	 * @param range
	 * @param queryPoint
	 */
	public void queryDisk(List results, float range, Pivot queryPoint) {

		queryDisk(results, root, range, queryPoint);
	}

	/**
	 * for every tree, search the whole tree unless pivot's 1/2*range nearest
	 * neighbor number is already larger than k
	 * 
	 * @param r
	 * @param range
	 * @param queryPoint
	 */
	private void queryDisk(List results, Node r, float range, Pivot queryPoint) {
		/**
		 * if the pivot and its nearest neighbors could not be outliers return
		 */
		// if (queryPoint.get_num_half_range_neighbors() >= K) {
		// return;
		// }
		if (parent.isStop(queryPoint))
			return;
		/**
		 * if r == null return
		 */
		/**
		 * if r is an instance of leaf node squential scan on the leaf nodes
		 */
		if (r instanceof LeafNode) {
			/**
			 * sequential scan in leaf node
			 */
			Pivot[] pivots = ((LeafNode) r).getPivots();
			for (int i = 0; i < pivots.length; i++) {
				// if (pivots[i] != null) {
				/**
				 * calculate the Lp-2 distance with each pivot
				 */
				// float dist = parent.distance_Lp_2(pivots[i].getPoint(),
				// queryPoint.getPoint());
				/**
				 * see if distance less than the range if yes, join the two
				 * pivots 2e-query
				 */
				results.add(pivots[i]);
				// parent.pivotJoin(queryPoint, pivots[i]);
				// if (pivots[i].get_num_half_range_neighbors() >= K)
				// return;
				// /**
				// * see if distance less than 1/2*e if yes join the pivots
				// */
				// if (dist < 0.25 * range) {
				// /**
				// * increase the pivot's hal_range_number
				// */
				// queryPoint.increase_half_range_neighbors();
				// if (queryPoint.get_num_half_range_neighbors() > k) {
				// return;
				// }
				// }
				// }
			}
		} else {
			/**
			 * if r is not leaf node, go into its child or children
			 * 
			 */
			/**
			 * search in the internal node
			 */
			Pivot pivot = r.getPivot();
			if (Math
					.abs(parent.getSlidingWindowEnd() - r.getPivot().getPoint()) > Memory.memoryForWindow
					- Memory.memoryForTree) {

				Memory.IOcost++;
			}
			// if(pivot ==null)
			// System.out.println("the pivot in Node is null!!!");
			/**
			 * the distance between vantage pivot and query point
			 */
			// if(parent != null)
			// System.out.println("Parent is not null!!!!!");
			float dist = Memory.distance_Lp_2(pivot.getPoint(), queryPoint
					.getPoint());
			/**
			 * go to left child
			 */
			if (dist < r.getPartitionDistance() - range) {
				// go to the left child of current node
				queryDisk(results, r.getLeftChild(), range, queryPoint);
			} else if (dist > r.getPartitionDistance() + range) {
				// go to right child of current node
				queryDisk(results, r.getRightChild(), range, queryPoint);
			} else {
				// go to both children the current node
				/**
				 * go to both children
				 */
				queryDisk(results, r.getLeftChild(), range, queryPoint);
				queryDisk(results, r.getRightChild(), range, queryPoint);
			}
		}

	}

	public int getSize() {
		return sizeof(root);
	}

	public int sizeof(Node node) {
		if (node instanceof LeafNode)
			return 10;
		else {
			//int subsequenceLength = Integer.parseInt(System
			//		.getProperty("SubsequenceLength"));
			return 4 + sizeof(node.getLeftChild())
					+ sizeof(node.getRightChild());
		}
	}
}
