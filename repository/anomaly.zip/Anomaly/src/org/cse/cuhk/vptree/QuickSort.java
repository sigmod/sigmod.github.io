package org.cse.cuhk.vptree;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class is to sort a float array by quick sort algorithm
 * 
 */

public class QuickSort {
	private static long comparisons = 0;

	private static long exchanges = 0;

	/***************************************************************************
	 * Quicksort code from Sedgewick 7.1, 7.2.
	 **************************************************************************/
	public static float[] quicksort(float[] b) {
		float[] a = new float[b.length];
		for (int i = 0; i < a.length; i++)
			a[i] = b[i];
		shuffle(a); // to guard against worst-case
		quicksort(a, 0, a.length - 1);
		return a;
	}

	public static void quicksort(float[] a, int left, int right) {
		if (right <= left)
			return;
		int i = partition(a, left, right);
		quicksort(a, left, i - 1);
		quicksort(a, i + 1, right);
	}

	private static int partition(float[] a, int left, int right) {
		int i = left - 1;
		int j = right;
		while (true) {
			while (less(a[++i], a[right]))
				// find item on left to swap
				; // a[right] acts as sentinel
			while (less(a[right], a[--j]))
				// find item on right to swap
				if (j == left)
					break; // don't go out-of-bounds
			if (i >= j)
				break; // check if pointers cross
			exch(a, i, j); // swap two elements into place
		}
		exch(a, i, right); // swap with partition element
		return i;
	}

	// is x < y ?
	private static boolean less(float x, float y) {
		comparisons++;
		return (x < y);
	}

	// exchange a[i] and a[j]
	private static void exch(float[] a, int i, int j) {
		exchanges++;
		float swap = a[i];
		a[i] = a[j];
		a[j] = swap;
	}

	// shuffle the array a
	private static void shuffle(float[] a) {
		int N = a.length;
		for (int i = 0; i < N; i++) {
			int r = i + (int) (Math.random() * (N - i)); // between i and N-1
			exch(a, i, r);
		}
	}
}
