package org.cse.cuhk.vptree;

import org.cse.cuhk.stream.application.Pivot;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * This class is of nodes in a VP-tree
 * 
 */
public class Node {

	/**
	 * the vantage pivot of this internal node of the tree
	 */
	private Pivot pivot = null;

	/**
	 * the partition distance of this internal node implies which branch will be
	 * searched, or both
	 */
	private double partition_distance = 0.0;

	/**
	 * the left child of current internal node
	 */
	private Node left = null;

	/**
	 * the right child of current internal node
	 */
	private Node right = null;

	/**
	 * the constructor of the internal tree node
	 */
	public Node() {

	}

	/**
	 * the constructor of the internal tree node
	 * 
	 * @param p
	 *            the pivot point
	 */
	public Node(Pivot p) {
		pivot = p;
	}

	/**
	 * the paramtered constructor of the internal tree node
	 * 
	 * @param p
	 *            the pivot
	 * @param l
	 *            the left child
	 * @param r
	 *            the right child
	 * @param distance
	 *            the partition distance
	 */
	public Node(Pivot p, Node l, Node r, double distance) {
		pivot = p;
		left = l;
		right = r;
		partition_distance = distance;
	}

	/**
	 * set the children of the internal node
	 * 
	 * @param l
	 * @param r
	 */
	public void setChildren(Node l, Node r) {
		left = l;
		right = r;
	}

	/**
	 * set the partition distance
	 * 
	 * @param distance
	 */
	public void setPartitionDistance(double distance) {
		partition_distance = distance;
	}

	/**
	 * get the left child of current internal node
	 * 
	 * @return the left child of current internal node
	 */
	public Node getLeftChild() {
		return left;
	}

	/**
	 * get the right child of current internal node
	 * 
	 * @return the right child of current internal node
	 */
	public Node getRightChild() {
		return right;
	}

	/**
	 * get the partition distance
	 * 
	 * @return the partition distance
	 */
	public double getPartitionDistance() {
		return partition_distance;
	}

	/**
	 * get the vantage pivot
	 * 
	 * @return the vantage pivot of current internal tree node
	 */
	public Pivot getPivot() {
		return pivot;
	}
}
