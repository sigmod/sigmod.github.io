package org.cse.cuhk.vptree;

import junit.framework.TestCase;

public class TestVPTree extends TestCase {

	/*
	 * Test method for 'org.cse.cuhk.vptree.VPTree.VPTree(int[], double[][])'
	 */
	public void testVPTree() {

		double [][]distance ={{0.0, 1.0, 2.0, 2.5},
							  {1.0, 0.0, 1.0, 1.5},
							  {2.0, 1.0, 0.0, 0.5},
							  {2.5, 1.5, 0.5, 0.0}};
//		int pivots[] = {100, 200, 300, 400};
//		VPTree tree = new VPTree(pivots, distance);
		int x=5;
		x++;
	}

}
