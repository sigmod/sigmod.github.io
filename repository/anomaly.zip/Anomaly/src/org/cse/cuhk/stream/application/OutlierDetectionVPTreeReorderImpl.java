package org.cse.cuhk.stream.application;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import org.cse.cuhk.vptree.VPTree;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class is to implement the outlier detection interface
 */

public class OutlierDetectionVPTreeReorderImpl implements OutlierDetection {

	private float max_pivot_radii = 0;

	/**
	 * the size of the buffer
	 */
	private int bufferSize = 0;

	/**
	 * the size of piece window
	 */
	private int pieceWindowSize = 0;

	/**
	 * the length of subsequence, which is fixed by algorithm parameter
	 */
	private int subsequenceLength = 0;

	/**
	 * the point to current pivot
	 */
	private Pivot current_pivot = null;

	/**
	 * the matrix of pairwise distance
	 */
	private float[][] current_distances;

	/**
	 * current status, is to extend pivot or not
	 */
	private boolean isExtend = true;

	/**
	 * the range d of k-d outlier definition
	 */
	private float range = 0;

	/**
	 * the half of the parameter range d
	 */
	private float half_range = 0;

	/**
	 * the max size of left bin or right bin
	 */
	private int binMaxSize = 0;

	/**
	 * the list of piecewise vp-trees
	 */
	private List trees = new LinkedList(); // the vp-trees indexing previous

	/**
	 * the parameter k of k-d outlier
	 */
	private int K = 0;

	/**
	 * the start of the sliding window
	 */
	private int slidingWindowStart = 0;

	/**
	 * the end of the sliding window
	 */
	private int slidingWindowEnd = 0;

	/**
	 * the sliding window length
	 */
	private int slidingWindowSize = 0;


	/**
	 * the list of oldest pivots to be removed
	 */
	private List toRemove = new Vector();

	/**
	 * the list of new coming pivots to be used to build a tree
	 */
	private List newComing = new Vector();

	/**
	 * the list of pivots in some trees
	 */
	private List pivots = new Vector();

	/**
	 * the default constructor
	 * 
	 */
	public OutlierDetectionVPTreeReorderImpl() {

		try {
			/**
			 * new the log object
			 */
			Memory.log = new PrintWriter(new OutputStreamWriter(
					new FileOutputStream("log/" + Memory.dataFile
							+ "-running-pwvp.log")));
		} catch (Exception e) {
			e.printStackTrace();
		}

		/**
		 * initialize buffer size
		 */
		bufferSize = Integer.parseInt(System.getProperty("BufferSize"));

		/**
		 * the size of active window
		 */
		pieceWindowSize = Integer.parseInt(System.getProperty("PieceWindow"));

		/**
		 * the parameter of k-d outlier
		 */
		K = Integer.parseInt(System.getProperty("K"));

		/**
		 * initialize the size of sliding window
		 */
		slidingWindowSize = Integer.parseInt(System
				.getProperty("SlidingWindowSize"));
		/**
		 * intialize the subsequence length
		 */
		subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));

		/**
		 * the max size of a bin, intialize to half subsequence length
		 */
		binMaxSize = subsequenceLength * 2;

		// the pairwise distances among pivots in current piece window
		current_distances = new float[pieceWindowSize][pieceWindowSize];

		// set the current distance
		for (int i = 0; i < current_distances.length; i++)
			for (int j = 0; j < current_distances.length; j++) {
				current_distances[i][j] = 0;
			}

		Memory.loadData();
		/**
		 * the range d for k-d outlier
		 */
		range = Memory.calculateRange();
	}

	/**
	 * keep the window sliding continuously
	 * 
	 */
	public void keepSliding() {
		
		initialWindow();
		/**
		 * set the new pivot array, initialize as the oldest tree's indexed
		 * pivots
		 */
		VPTree vp = (VPTree) trees.get(0);
		/**
		 * get the pivots of the VP-tree
		 */
		Pivot[] oldest = vp.getPivots();

		/**
		 * add the oldest pivots into list of pivots to be removed
		 */
		for (int i = 0; i < oldest.length; i++) {
			toRemove.add(oldest[i]);
		}

		System.out.println("to remove size " + toRemove.size());
		System.out.println("number of trees " + trees.size());
		/**
		 * remove the 1st tree
		 */
		trees.remove(0);
		/**
		 * set up the start and end of sliding window
		 */
		/**
		 * start to sliding the window
		 */
		int start = this.slidingWindowEnd + 1;
		long begin = System.currentTimeMillis();
		Memory.clearDistanceCounter();
		Memory.clearIOcost();
		Memory.clearBlockAccess();
		for (int i = start; i < this.bufferSize; i++) {
			this.onSliding();
			// System.out.println("memory size: " + Memory.memoryForWindow);
			// System.out.println("tree size: "+ Memory.memoryForTree);
		}
		long end = System.currentTimeMillis();
		System.out.println("Total time: " + (end - begin));
		Memory.log.println("Total time: " + (end - begin));
		Memory.log.println("Total Distance Computation: "
				+ Memory.getDistanceComputation());
		Memory.log.println("Window Size: "
				+ (slidingWindowEnd - slidingWindowStart));
		Memory.log.println("Slide Steps: " + (bufferSize - start));
		Memory.log.println("IO Cost: " + Memory.getBlockAccess());
		Memory.clearDistanceCounter();
		Memory.clearBlockAccess();
		Memory.log.flush();

		int size = 0;
		for (int i = 0; i < trees.size(); i++) {
			VPTree tree = (VPTree) trees.get(i);
			size = size + tree.getSize();
		}
		Memory.log.println("VP-Trees total Size " + size);
		Memory.log.flush();
		// Memory.log.println();
	}

	/**
	 * used when the sliding window is intializing
	 */
	private List sameTreePivots = new Vector();

	/**
	 * indicate if the outliers is found
	 */
	private int recentOutlier = -1;

	/**
	 * intialize the slding window, calculate pivots return the sliding window
	 * Size
	 */
	public int initialWindow() {
		this.isExtend = true;
		slidingWindowStart = this.subsequenceLength - 1;
		slidingWindowEnd = slidingWindowStart + slidingWindowSize;
		current_pivot = new Pivot(subsequenceLength - 1);
		this.isExtend = false;

		this.half_range = range / 2;
		
		System.out.println("half range "+this.half_range);
		// List sameTreePivots = new Vector();
		for (int i = this.slidingWindowStart; i < slidingWindowEnd; i++) {
			calculatePivot(i);
			//if(i%100==0)
			//	System.out.println("initialized "+i);
		}
		Memory.log.flush();

		/**
		 * set up the parameters of Sliding Window
		 */
		slidingWindowEnd = current_pivot.getEnd();
		slidingWindowStart = subsequenceLength - 1;
		// slidingWindowSize = slidingWindowEnd - slidingWindowStart + 1;
		int size = 0;
		for (int i = 0; i < trees.size(); i++) {
			VPTree tree = (VPTree) trees.get(i);
			size = size + tree.getSize();
		}
		System.out.println("VP-Trees total Size " + size);

		/**
		 * memory size for tree and memory size for window the same cache is
		 * used
		 */
		Memory.memoryForTree = size;
		Memory.memoryForWindow = 2 * Memory.memoryForTree;
		return slidingWindowEnd - slidingWindowStart;
	}

	private float current_radii = 0;

	/**
	 * initlize pivots, list and trees
	 * 
	 * @param position
	 * @param pivots
	 */
	private void initialPivot(int position) {
		/**
		 * if in the extending phase
		 */
		if (isExtend) {
			int start = subsequenceLength - 1;
			if (current_pivot != null)
				start = current_pivot.getEnd() + 1;

			boolean isIn = true;
			for (int i = start; i < position; i++) {
				float dist = Memory.distance_Lp_2(i, position);
				if (dist > this.half_range) {
					isIn = false;
					break;
				}
				if (dist < this.half_range && dist > current_radii) {
					current_radii = dist;
				}
			}
			if (isIn == false || position - start > this.binMaxSize) {
				/**
				 * set up a new pivot
				 */
				// Pivot temp =
				current_pivot = new Pivot(position - 1);
				current_pivot.setStart(start);
				current_pivot.setEnd(position - 1);
				// System.out.println("find pivot " + sameTreePivots.size() + "
				// "
				// + position + " tree" + trees.size());
				/**
				 * set the pivot of every subsequence covered by current pivot
				 */
				// for (int j = start; j < position; j++) {
				// Memory.buffer[j].setPivot(current_pivot);
				// }
				isExtend = false;
				/**
				 * insert pivot into list
				 */
				sameTreePivots.add(current_pivot);
			}
		}
		if (isExtend == false) {
			/**
			 * is not in the extending phase
			 */
			int point = current_pivot.getPoint();
			float dist = Memory.distance_Lp_2(point, position);
			/**
			 * set the subsequence's pivot value
			 */
			if (dist < this.half_range && position - point < this.binMaxSize) {
				// Memory.buffer[position].setPivot(current_pivot);
				if (dist > current_radii) {
					current_radii = dist;
				}
			} else {
				isExtend = true;
				/**
				 * set the end of current pivot
				 */
				current_pivot.setEnd(position - 1);

				current_pivot.setRadii(current_radii);

				if (current_pivot.getRadii() > this.max_pivot_radii)
					max_pivot_radii = current_pivot.getRadii();

				current_radii = 0;
				// for (int i = current_pivot.getStart(); i <= current_pivot
				// .getEnd(); i++) {
				// Memory.buffer[i].setPivot(current_pivot);
				// }
				/**
				 * get the pairwise distance
				 */
				int size = sameTreePivots.size() - 1;
				boolean needJoin = true;
				for (int i = 0; i < size; i++) {
					Pivot p = (Pivot) sameTreePivots.get(i);
					int pos = p.getPoint();
					float distance = Memory.distance_Lp_2(pos, position);
					this.current_distances[size][i] = distance;
					this.current_distances[i][size] = distance;
					if (needJoin == true)
						Memory.joinPivots(current_pivot, p, slidingWindowEnd,
								range);
					if (isStop(current_pivot)) {
						needJoin = false;
					}
				}
				boolean stop = false;
				if (isStop(current_pivot))
					stop = true;
				if (stop == false) {
					for (int i = 0; i < trees.size(); i++) {
						VPTree t = (VPTree) trees.get(i);
						t
								.query(2 * this.max_pivot_radii + range,
										current_pivot);
						if (isStop(current_pivot))
							break;
					}
				}

				/**
				 * when pivot number is full build a vptree
				 */
				if (sameTreePivots.size() >= this.pieceWindowSize) {
					size = sameTreePivots.size();
					Pivot[] parray = new Pivot[size];
					/**
					 * copy list to array
					 */
					for (int j = 0; j < parray.length; j++)
						parray[j] = (Pivot) sameTreePivots.get(j);
					/**
					 * new a VPTree
					 */
					VPTree t = new VPTree(parray, current_distances);
					t.setParent(this);
					t.checkPivots();
					/**
					 * add the new VPTree into the tree list
					 */
					trees.add(t);

					for (int i = 0; i < sameTreePivots.size() - 1; i++) {
						Pivot p1 = (Pivot) sameTreePivots.get(i);
						Pivot p2 = (Pivot) sameTreePivots.get(i + 1);
						if (p1.getEnd() + 1 != p2.getStart()) {
							Memory.log.println(p1.getPoint() + " s "
									+ p1.getStart() + " e " + p1.getEnd());
							Memory.log.flush();
						}
					}
					/**
					 * clear the pivot list
					 */
					sameTreePivots.clear();
				}
				/**
				 * insert pivot into list
				 */
				pivots.add(current_pivot);
			}
		}
	}

	/**
	 * sliding the sliding widnow for 1 step
	 * 
	 */
	public void onSliding() {
		// TODO Auto-generated method stub
		this.slidingWindowEnd++;
		/**
		 * calculate pivot position based on new coming data value
		 */
		// if (this.slidingWindowEnd < this.bufferSize)
		calculatePivot(slidingWindowEnd);
		/**
		 * reporting if the start of sliding window is an outlier
		 */
		if (slidingWindowStart - recentOutlier >= subsequenceLength) {
			recentOutlier = judgeOldestOutlier(slidingWindowStart);
		}

		/**
		 * put an entire tree into the toRemove List
		 */
		if (toRemove.size() == 0) {

			/**
			 * set the to remove pivot array, initialize as the oldest tree's
			 * indexed pivots
			 */
			VPTree vp = (VPTree) trees.get(0);
			/**
			 * get the pivots of the VP-tree
			 */
			Pivot[] oldest = vp.getPivots();
			/**
			 * add the oldest pivots into the queue
			 */
			for (int i = 0; i < oldest.length; i++) {
				toRemove.add(oldest[i]);
			}

			/**
			 * move the deleted pivot's right bin into a preparing deletion list
			 */
			trees.remove(0);
		}
		/**
		 * remove the start position of the sliding window
		 */
		removeOldest(slidingWindowStart);
	}

	/**
	 * calculate the pivot position
	 * 
	 * @param end_position
	 */
	private void calculatePivot(int position) {
		/**
		 * if in the extending phase
		 */
		if (isExtend) {
			int start = 0;
			if (current_pivot != null)
				start = current_pivot.getEnd() + 1;

			boolean isIn = true;
			for (int i = start; i < position; i++) {
				float dist = Memory.distance_Lp_2(i, position);
				if (dist > this.half_range) {
					isIn = false;
					break;
				}
				if (dist < this.half_range && dist > current_radii) {
					current_radii = dist;
				}
			}
			if (isIn == false || position - start > this.binMaxSize) {
				isExtend = false;
				/**
				 * set up pivot into list
				 */
				current_pivot = new Pivot(position - 1);
				current_pivot.setStart(start);
				current_pivot.setEnd(position - 1);
			}
		}
		if (isExtend == false) {
			/**
			 * is not in the extending phase
			 */
			int point = current_pivot.getPoint();
			float dist = Memory.distance_Lp_2(point, position);
			/**
			 * set the subsequence's pivot value
			 */
			if (dist < this.half_range && position - point < this.binMaxSize) {
				// Memory.buffer[position].setPivot(current_pivot);
				if (dist > current_radii) {
					current_radii = dist;
				}
			} else {
				isExtend = true;
				/**
				 * set the end of current pivot
				 */
				current_pivot.setEnd(position - 1);

				current_pivot.setRadii(current_radii);

				if (current_pivot.getRadii() > this.max_pivot_radii)
					max_pivot_radii = current_pivot.getRadii();

				current_radii = 0;
				
				/**
				 * add the new pivot to current piece window and pivot list
				 */
				newComing.add(current_pivot);
				pivots.add(current_pivot);
				
				/**
				 * execute the range query on current pivot point just after
				 */
				calculatePivotRangeQueryLeft(current_pivot);
                //System.out.println("pivot at: "+current_pivot.getPoint());

				/**
				 * if new coming pivot reach the head of the queue since all the
				 * oldest pivots have been moved out of the queue
				 */
				int size = newComing.size();
				if (size >= this.pieceWindowSize) {
					/**
					 * copy current piece window in to window
					 */
					Pivot[] window = new Pivot[newComing.size()];
					for (int i = 0; i < window.length; i++)
						window[i] = (Pivot) newComing.get(i);
					/**
					 * construct a new VP-tree
					 */
					VPTree tree = new VPTree(window, current_distances);

					/**
					 * set the new VP-tree's parent to this Outlier Detection
					 * object
					 */
					tree.setParent(this);

					/**
					 * put the new VP-tree into the tree array
					 */
					trees.add(tree);

					/**
					 * clear current piece window
					 */
					newComing.clear();
				}
			}
		}
		Memory.log.flush();
	}

	/**
	 * execute similarity range query over the sliding window along the left
	 * direction, thus the distance matrix needing to be updated
	 * 
	 * @param pivot
	 */
	private void calculatePivotRangeQueryLeft(Pivot pivot) {

		/**
		 * query by squential scan on the most recent pivots and the oldest
		 * pivots
		 */
		int queue_length = this.newComing.size();

		/**
		 * Join with the new coming pivots which haven't formed a tree yet
		 */
		for (int i = 0; i < queue_length - 1; i++) {
			/**
			 * the candidate pivot to be compared
			 */
			Pivot comparing_pivot = (Pivot) newComing.get(i);
			/**
			 * calculate the Lp-2 distance between pivot and comparing pivot
			 */
			float dist = Memory.distance_Lp_2(comparing_pivot.getPoint(),
					current_pivot.getPoint());

			/**
			 * set the distance matrix entry of comparing pivot and current
			 * pivot
			 */
			current_distances[queue_length - 1][i] = dist;
			current_distances[i][queue_length - 1] = dist;
		}
		/**
		 * self distance is 0
		 */

		current_distances[queue_length - 1][queue_length - 1] = 0;

		query(pivot);
	}

	private void query(Pivot pivot) {
		/**
		 * judge if further search is necessary
		 */
		if (isStop(pivot))
			return;
		/**
		 * execute range queries on both current pivot and previous vp-trees
		 * 
		 */
		/**
		 * the possible candidates
		 */
		List toBeJoined = new Vector();

		for (int i = 0; i < trees.size(); i++) {
			VPTree tree = (VPTree) trees.get(i);
			if (tree != null) {
				/**
				 * query in the VP-trees
				 */
				tree.queryDisk(toBeJoined, 2 * max_pivot_radii + range, pivot);
				/**
				 * judge if the pivot and its bin could not be outliers
				 */
				if (!isStop(pivot)) {
					if (i % 2 == 0) {
						joinSchedule(pivot, toBeJoined);
						toBeJoined.clear();
					}
				} else
					return;

			}
		}

		joinSchedule(pivot, newComing);

		joinSchedule(pivot, toRemove);
	}

	/**
	 * 
	 * @param pivot
	 * @return
	 */
	public boolean isStop(Pivot pivot) {
		if (pivot.get_num_half_range_neighbors() >= K) {
			return true;
		}
		/**
		 * if every element in the pivot's bin is not outlier, then the search
		 * could be breaked
		 */
		boolean impossible = true;
		for (int j = pivot.getStart(); j <= pivot.getEnd(); j++) {
			if (Memory.buffer[j].getNNCount() < K)
				impossible = false;
		}
		return impossible;
	}

	/**
	 * calculate range query along the right direction for the query pivot
	 * 
	 * @param pivot
	 *            the query pivot
	 */
	private void calculateRangeQueryRight(Pivot pivot) {

		query(pivot);
	}

	/**
	 * judge if the oldest subsequence is an outlier
	 * 
	 * @param position
	 */
	private int judgeOldestOutlier(int position) {

		Pivot piv = (Pivot) pivots.get(0);
		// Pivot first = (Pivot) toRemove.get(0);

		if (!(piv.getStart() <= position && position <= piv.getEnd())) {
			System.out.println("pivot error!!!!" + " " + position + " "
					+ piv.getStart() + " " + piv.getEnd());
			getLog().println("pivot error");
		}

		if (piv.get_num_half_range_neighbors() >= K)
			return -1;
		/**
		 * if position is not outlier, nothing to be done
		 */
		if (Memory.buffer[position].getNNCount() >= this.K)
			return -1;
		/**
		 * if the right part is not searched
		 */
		if (!piv.getSearchedRight()) {
			/**
			 * if the pivot is not searched on the right direction search the
			 * right first
			 */
			this.calculateRangeQueryRight(piv);
			/**
			 * set right to be searched
			 */
			piv.setSearchRight();
			/**
			 * set the right most position searched
			 */
			int rightMost = 0;
			if (newComing.size() != 0) {
				/**
				 * if newComing list is not null
				 */
				Pivot right = (Pivot) newComing.get(newComing.size() - 1);
				rightMost = right.getEnd();
			} else {
				/**
				 * if newComing list is null then get tree's right most
				 */
				// VPTree t = (VPTree) trees.get(trees.size() - 1);
				// int ppos = t.getEnd();
				Pivot newestPivot = (Pivot) pivots.get(pivots.size() - 1);
				rightMost = newestPivot.getEnd();
			}
			/**
			 * set the end position of right most
			 */
			piv.setRightMostSearch(rightMost);

			// if (position == 1053) {
			// Memory.log.println("after search:");
			// Memory.log.println("position " + position + " "
			// + Memory.buffer[position].getNNCount());
			// Memory.log.println("pivot pos " + piv.getPoint() + " begin at "
			// + piv.getStart() + " end at " + piv.getEnd() + " NN "
			// + piv.get_num_half_range_neighbors() + " "
			// + Memory.buffer[piv.getPoint()].getNNCount());
			// }
			/**
			 * if position is not outlier, nothing to be done
			 */
			if (Memory.buffer[position].getNNCount() >= this.K)
				return -1;

		}

		/**
		 * if not outlier, return
		 */
		if (Memory.buffer[position].getNNCount() >= this.K)
			return -1;

		/**
		 * Handle the marginal situation! the right part is searched get the
		 * right most position that has been searched
		 * 
		 * Although right part is searched there is still some marginal points
		 * missed
		 */
		int rMost = piv.getRightMostSearch();
		/**
		 * the start position of search in this round
		 */
		int start = rMost + 1;

		for (int i = start; i <= this.slidingWindowEnd; i++)
			Memory.subsequenceJoin(position, i, range);
		/**
		 * if the pivot is null, means it's in extending phase sequential scan
		 * it's right position in the sliding window
		 */
		if (Memory.buffer[position].getNNCount() >= K)
			return -1;
		/**
		 * report outlier
		 */
		boolean isFind = false;
		for (int i = position; i >= subsequenceLength - 1
				&& i > position - subsequenceLength; i--) {
			if (Memory.buffer[i].isOutlier()) {
				isFind = true;
				break;
			}
		}
		if (isFind == false) {
			Memory.buffer[position].markOultier();
			System.out.println("finding outlier at " + position + " NN "
					+ Memory.buffer[position].getNNCount() + "  K " + K);
			Memory.log.println("finding outlier at " + position + " NN "
					+ Memory.buffer[position].getNNCount() + "  K " + K);
			Memory.log.flush();
		}
		return position;

	}

	/**
	 * remove the oldest subsequences and the oldest pivot/tree if necessary
	 * 
	 * @param position
	 */
	private void removeOldest(int position) {
		Pivot p = (Pivot) pivots.get(0);

		if (!(p.getStart() <= position && p.getEnd() >= position))
			getLog().println(" pivots error!!! ");
		/**
		 * if the oldest one is not a pivot and in its right bin change its
		 * pivot's start the pivot might become a virtual pivot
		 */
		if (position < p.getEnd()) {
			p.setStart(position + 1);
		}
		/**
		 * reach the end of a pivot, the pivot is of no use since then
		 */
		if (position == p.getEnd()) {

			pivots.remove(0);
			toRemove.remove(0);
			/**
			 * the removing position is a pivot then change current piece window
			 * delete the oldest pivot and remove it from current piece window
			 */
			// VPTree leftMost = (VPTree) trees.get(0);
			// pivot_start_position--;
			/**
			 * if the pivot doesn't reach the left most tree
			 */
			// if (p.getPoint() < leftMost.getStart()) {
			/**
			 * remove the pivot
			 */

			// }
			/**
			 * if the pivot reach the left most tree disable the left most tree
			 */
			// else {
			//
			// }
		}
		this.slidingWindowStart++;
	}

	public PrintWriter getLog() {
		return Memory.log;
	}

	public void test() {
		int pos = 1085;
		half_range = range / 2;
		int n = 0;
		for (int i = subsequenceLength - 1; i <= 131948; i++) {
			if (Math.abs(i - pos) > subsequenceLength) {
				float dist = Memory.distance_Lp_2(pos, i);
				if (dist < this.half_range) {
					System.out.println(i + " is in half range to " + pos);
					Memory.log.println(i + " is in half range to " + pos);
					n++;
				}
			}
		}
		System.out.println(pos + " Half NN " + n);
		// Memory.log.println(pos + " standard NN "
		// + Memory.buffer[pos].getNNCount());
		// Memory.log.flush();
	}

	public int getSlidingWindowEnd() {
		return slidingWindowEnd;
	}

	/**
	 * schedule the join and optimize the query cost
	 * 
	 * @param candidates
	 */
	private void joinSchedule(Pivot query, List candidates) {
		List pivots = reorderCandidates(query, candidates);
		// List pivots = candidates;
		for (int i = 0; i < pivots.size(); i++) {
			Pivot p = (Pivot) pivots.get(i);
				if (query != p) {
				Memory.joinPivots(query, p, slidingWindowEnd, range);
				/**
				 * there is a redudent distance computation
				 * which should be removed
				 */
				Memory.distance_computation--;
				}
			/**
			 * if stop condition comes stop the join
			 */
			if (isStop(query))
				break;
		}
	}

	/**
	 * reorder the candidates, to group pivots on the same block together
	 * 
	 * @param candidates
	 * @return
	 */
	private List reorderCandidates(Pivot query, List pivots) {
		/**
		 * new a Candidate List
		 */
		List candidates = new Vector();
		for (int i = 0; i < pivots.size(); i++) {
			Pivot pivot = (Pivot) pivots.get(i);
			/**
			 * get the dist
			 */
			float dist = Memory.distance_Lp_2(query.getPoint(), pivot
					.getPoint());
			Candidate candidate = new Candidate(pivot, dist);
			/**
			 * add the candidate to candidates' list
			 */
			candidates.add(candidate);
		}

		/**
		 * sort the candidates
		 */
		Collections.sort(candidates);
		List result_order = new Vector();

		/**
		 * get the candidate
		 */
		// System.out.println("to be join size: " + result_order.size());
		for (int i = 0; i < candidates.size(); i++) {
			Candidate c = (Candidate) candidates.get(i);
			result_order.add(c.getPivot());
			// System.out.println(c.getDistance());
		}
		/**
		 * return the result ordered candidate list
		 */
		return result_order;
	}


	public float getRange() {
		return range;
	}
}
