package org.cse.cuhk.stream.application;


public class TestBFOutlierImpl{

	/*
	 * Test method for
	 * 'org.cse.cuhk.stream.application.OutlierDetectionBFImpl.keepSliding()'
	 */
	public static void testKeepSliding() {
		OutlierDetection detect = new OutlierDetectionBFImpl();
		detect.keepSliding();
	}

	public static void main(String[] args) {
		Memory.initializeSystemProperties();
		Memory.dataFile = "data/movement.dat";
		testKeepSliding();
	}
}
