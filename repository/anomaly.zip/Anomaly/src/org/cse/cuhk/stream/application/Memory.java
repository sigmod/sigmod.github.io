package org.cse.cuhk.stream.application;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.cse.cuhk.stream.StreamConstants;

public class Memory {

	public static float[][][] dwtWindow = null;

	public static int blockAccess = 0;

	public static int blockSize = 0;

	public static Cache cache = null;

	public static int subsequenceLength = 0;

	public static int memoryForWindow = 40000;

	public static int memoryForTree = 4000;

	public static int IOcost = 0;

	public static long distance_computation = 0;

	private static float range = 0;

	public static String dataFile = null;

	public static PrintWriter log = null;

	/**
	 * intialize the page offset
	 */
	public static final int pageOffset = 1000;

	/**
	 * a buffer for subsequences
	 */
	static Subsequence[] buffer; // store whole data stream

	/**
	 * maintain a list as pivot repository static
	 */
	public static List pivotRepository = new Vector();

	/**
	 * the dimension of trajectory data
	 */
	public static int dimension = 0;

	/**
	 * Load data to buffer from dataset, when buffer is longer, duplicate the
	 * data, in order to simulate a stream time series
	 * 
	 * @param dataset
	 */
	public static void loadData() {
		try {

			int bufferSize = Integer.parseInt(System.getProperty("BufferSize"));
			int size = 0;
			float[][] data;
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("data/" + Memory.dataFile)));

			String line = "";
			int number = 0;
			dimension = 0;
			while ((line = reader.readLine()) != null) {
				if (number == 0) {
					// get the dimension of data
					dimension = line.split(" ").length;
				}
				number++;
			}
			size = number;
			data = new float[size][dimension];
			reader.close();
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("data/" + Memory.dataFile)));

			int i = 0;
			while ((line = reader.readLine()) != null) {
				String[] row = line.split(" ");
				float[] value = new float[dimension];
				for (int d = 0; d < dimension; d++) {
					value[d] = Float.parseFloat(row[d]);
					data[i][d] = value[d];
				}
				i++;
			}

			normalization(data);
			// smooth(data);
			Memory.buffer = new Subsequence[bufferSize];

			/**
			 * intialize the buffer
			 */
			for (i = 0; i < Memory.buffer.length; i++) {
				// float noise = ((float) Math.random()) / 100000;
				float[] tempRow = new float[dimension];
				for (int d = 0; d < dimension; d++) {
					tempRow[d] = data[i % data.length][d]
							+ (float) Math.random() / 10000;
				}
				Memory.buffer[i] = new Subsequence(tempRow);
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));
		cache = new Cache(0, blockSize);

		blockSize = Integer.parseInt(System.getProperty("BlockSize"));
		System.out.println("data set has been loaded!!!");
	}

	/**
	 * normalization for the float array data
	 * 
	 * @param data
	 */
	private static void normalization(float[][] data) {

		for (int d = 0; d < dimension; d++) {
			float mean = 0;
			for (int i = 0; i < data.length; i++) {
				mean = mean + data[i][d];
			}
			mean = mean / (data.length - 1);
			float SD = 0;
			for (int i = 0; i < data.length; i++) {
				SD = SD + (data[i][d] - mean) * (data[i][d] - mean);
			}
			SD = (float) Math.sqrt((float) SD / (data.length - 1));
			for (int i = 0; i < data.length; i++) {
				data[i][d] = (data[i][d] - mean) / SD;
			}
		}
	}

	/**
	 * calculate the Lp-2 distance between 2 subsequences
	 */
	public static float distance_Lp_2(int pivot, int current) {

		// if(Math.abs(pivot - current)<subsequenceLength)
		// return Float.MAX_VALUE;

		distance_computation++;
		// int subsequenceLength = Integer.parseInt(System
		// .getProperty("SubsequenceLength"));
		// if (Math.abs(pivot - current + 1) < 2*this.binMaxSize)
		// return float.MAX_VALUE;
		int start1 = pivot - subsequenceLength + 1;
		int start2 = current - subsequenceLength + 1;
		// int dim = Memory.buffer[start1].getValue().length;

		float distance = 0;

		/**
		 * aggregate distance for different dimensions
		 */
		for (int d = 0; d < dimension; d++) {
			for (int i = 0; i < subsequenceLength; i++) {
				distance = distance
						+ (Memory.buffer[start1 + i].getValue()[d] - Memory.buffer[start2
								+ i].getValue()[d])
						* (Memory.buffer[start1 + i].getValue()[d] - Memory.buffer[start2
								+ i].getValue()[d]);
			}
		}
		return (float) Math.sqrt((float) distance);
	}

	/**
	 * intialize system properties
	 * 
	 */
	public static void initializeSystemProperties() {
		Properties props = new Properties();
		try {
			/**
			 * read the property files
			 */
			FileInputStream fis = new FileInputStream(
					StreamConstants.SYSTEM_PROPERTIES);
			props.load(fis);
			fis.close();
		} catch (FileNotFoundException e) {
			// Ignore file not found.
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		/**
		 * Push all loaded properties into System
		 */
		for (Enumeration e = props.propertyNames(); e.hasMoreElements();) {
			String name = (String) e.nextElement();
			System.setProperty(name, (String) props.getProperty(name));
		}
	}

	public static void free() {
		buffer = null;
		pivotRepository.clear();
		System.gc();
	}

	/*
	 * find the d of the K-d outlier definition
	 * 
	 * @return target d: diameter/15.0
	 */
	public static float calculateRange() {
		float diameter = 0;
		System.out.println(Memory.distance_Lp_2(3687, 3689));
		int sampleSize = buffer.length / 100;
		System.out.println("sample size: " + sampleSize);
		int comparingSize = buffer.length / 1000;
		System.out.println("comparing size: " + comparingSize);
		System.out.flush();
		int subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));
		for (int i = subsequenceLength - 1; i < sampleSize; i++) {
			for (int j = buffer.length - 1; j > buffer.length - comparingSize; j--) {
				float dist = Memory.distance_Lp_2(i, j);
				// System.out.println(dist);
				// if(dist == 0 )
				// System.out.println("wrong!");
				if (dist > diameter)
					diameter = dist;
			}
		}
		System.out.println("got diameter " + diameter);
		log.println("got diameter " + diameter);
		log.flush();

		range = diameter * (float) 0.1;

		return range;
	}

	public static long getDistanceComputation() {
		return distance_computation;
	}

	public static void clearDistanceCounter() {
		distance_computation = 0;
	}

	/**
	 * return the partial distance
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	// public static float DWTCoefficientDistance(float[][] a, float[][] b) {
	// // float maxJump = a[1] > b[1] ? a[1] : b[1];
	// float length = a[0][0];
	// float lowerbound_dist = 0;
	// for (int d = 0; d < dimension; d++) {
	// float partDist = (a[2][d] - b[2][d]) * (a[2][d] - b[2][d]) * length
	// / 4;
	// for (int i = 3; i < a.length; i++) {
	// partDist = partDist + (a[i][d] - b[i][d]) * (a[i][d] - b[i][d])
	// * length / 2;
	// }
	// lowerbound_dist += partDist;
	// }
	// return (float) Math.sqrt(lowerbound_dist);
	// }
	// public static float DWTCoefficientDistance(float[][] data_1,
	// float[][] data_2) {
	// float aggregatedDistance = 0;
	// for (int d = 0; d < dimension; d++) {
	// float D[] = new float[data_1.length];
	// for (int i = 0; i < D.length; i++)
	// D[i] = data_1[i][d] - data_2[i][d];
	// float square = D[0] * D[0];
	// int current = 1;
	// while (current < data_1.length) {
	// int start = current;
	// int end = 2 * current - 1;
	// /**
	// * it the value is not padded
	// */
	// if (end < data_1.length) {
	// for (int j = start; j <= end; j++)
	// square += D[j] * D[j];
	// }
	// square *= 2;
	// current *= 2;
	// }
	// aggregatedDistance += square;
	// }
	// return (float)Math.sqrt((double)aggregatedDistance);
	// }
	// public static float tansformDistance(int pivot, int current, int n) {
	// int subsequenceLength = Integer.parseInt(System
	// .getProperty("SubsequenceLength"));
	// int start1 = pivot - subsequenceLength + 1;
	// int start2 = current - subsequenceLength + 1;
	// float[] a = new float[subsequenceLength];
	// float[] b = new float[subsequenceLength];
	// for (int i = 0; i < a.length; i++) {
	// a[i] = buffer[start1 + i].getValue();
	// b[i] = buffer[start2 + i].getValue();
	// }
	// float[] t1 = CosineTransform.transform(a, n);
	// float[] t2 = CosineTransform.transform(b, n);
	// float distance = coefficientDistance(t1, t2);
	// return distance;
	// }
	/**
	 * reset the IO cost to 0
	 * 
	 */
	public static void clearIOcost() {
		IOcost = 0;
	}

	// /**
	// * join two pivots' bins p1: the later pivot p2: the previous pivot p1 is
	// * during the join phase, p1's nnCount is updated, but p2's nncount will
	// not
	// * be updated
	// *
	// * @p1 is the active pivot
	// * @p2 is the passive pivot
	// */
	// public static void pivotJoin(Pivot p1, Pivot p2, int end, float range) {
	// if (p1.getPoint() == p2.getPoint())
	// return;
	//
	// int available_memory = memoryForWindow - memoryForTree;
	//
	// /**
	// * if the point p2 is not in memory--the recent window then we load the
	// * load the block for p2 if necessary
	// */
	// if (Math.abs(end - p2.getPoint()) > available_memory) {
	// loadBlock(p2);
	// }
	//
	// float pdist = Memory.distance_Lp_2(p1.getPoint(), p2.getPoint());
	//
	// /**
	// * if the distance between two pivots is larger than 2*range, then, no
	// * further join phase is necessary
	// */
	// if (pdist > range + p1.getRadii() + p2.getRadii())
	// return;
	//
	// /**
	// * join p1 with p2's bin
	// */
	// for (int i = p2.getStart(); i <= p2.getEnd(); i++) {
	// pivotSubsequenceJoin(p1, i, range);
	// /**
	// * if stop condition comes
	// */
	// if (p1.isStop())
	// break;
	// }
	// }

	/**
	 * join two subsequnces, only increase s1's nnCount
	 * 
	 * @param s1
	 *            the active join subsequence
	 * @param s2
	 *            the passive join subsequence
	 */
	public static void subsequenceJoin(int s1, int s2, float range) {
		if (Math.abs(s1 - s2) < subsequenceLength)
			return;

		float dist = Memory.distance_Lp_2(s1, s2);
		/**
		 * if dist(s1,s2)<range return directly
		 */
		if (dist < range) {
			// if (s1 == 1085) {
			// System.out.println("Join 1085 with " + s2 + " successfully");
			// Memory.log.println("Join 1085 with " + s2 + " successfully");
			// }
			Memory.buffer[s1].increaseNNCount();
		}
	}

	/**
	 * join a pivot and a subsequnce
	 * 
	 * @param p1
	 *            is the active join pivot
	 * @param s
	 *            is the passive join subsequence
	 */
	public static void pivotSubsequenceJoin(Pivot p1, int subsequence_end,
			float range) {

		int i = subsequence_end;
		/**
		 * calculate the distance between i and p1
		 */
		float dist = Memory.distance_Lp_2(p1.getPoint(), i);

		/**
		 * if dist(p1, i)< (1/2)*range, all p1's bin element's distance to i
		 * are in 'range'
		 */
		if (dist < p1.getRadii() && p1.getRadii() < range) {

			if (Math.abs(i - p1.getStart()) < subsequenceLength
					&& Math.abs(i - p1.getEnd()) < subsequenceLength) {
				/**
				 * every subsequence is self-match
				 */
				;
			} else if (Math.abs(i - p1.getStart()) < subsequenceLength
					|| Math.abs(i - p1.getEnd()) < subsequenceLength) {
				/**
				 * if pivot and i is self -math identify if every subsequence
				 * coverd is
				 */
				for (int j = p1.getStart(); j <= p1.getEnd(); j++) {
					if (Math.abs(i - j) >= subsequenceLength)
						Memory.buffer[j].increaseNNCount();
				}
			} else {
				/**
				 * increase the number of half range neighbors
				 */
				p1.increase_half_range_neighbors();
				for (int j = p1.getStart(); j <= p1.getEnd(); j++) {
					/**
					 * increase the nearest neighbor count
					 */
					Memory.buffer[j].increaseNNCount();
				}
			}
		}
		/**
		 * if (1/2)*range<=dist(p1, i)< (3/2)*range, all p1's bin element's
		 * distance to i are possibly in 'range'
		 */
		else if (dist < range + p1.getRadii()) {
			for (int j = p1.getStart(); j <= p1.getEnd(); j++) {
				/**
				 * join the two subsequences: j and i, j is the active part
				 */
				subsequenceJoin(j, i, range);
				if (p1.isStop())
					return;
			}
		} else
			;
	}

	/**
	 * judage if a pivot is in cache
	 * 
	 * @param p
	 * @return
	 */
	public static boolean isInCache(Pivot p) {
		boolean isIn = false;
		if (p.getPoint() > cache.getStart() && p.getPoint() < cache.getEnd()) {
			isIn = true;
		}
		return isIn;
	}

	/**
	 * @param p
	 * @return
	 */
	public static void loadBlock(Pivot p) {
		/**
		 * if p is not in cache, load p
		 */
		if (!isInCache(p)) {
			int start = (p.getPoint() / blockSize) * blockSize;
			int end = start + blockSize;
			cache.start = start;
			cache.end = end;
			blockAccess++;
		}
	}

	/**
	 * get the numbe of block access
	 * 
	 * @return
	 */
	public static int getBlockAccess() {
		return blockAccess;
	}

	/**
	 * clear the number of block access
	 */
	public static void clearBlockAccess() {
		blockAccess = 0;
	}

	private static int current_count = 0;

	/**
	 * join two pivots' bins p1: the later pivot p2: the previous pivot p1 is
	 * during the join phase, p1's nnCount is updated, but p2's nncount will not
	 * be updated
	 * 
	 * @p1 is the active pivot
	 * @p2 is the passive pivot
	 */
	public static void joinPivots(Pivot p1, Pivot p2, int end, float range) {
		if (p1.getPoint() == p2.getPoint())
			return;

		boolean overlap = false;
		if (Math.abs(p2.getStart() - p1.getEnd()) < subsequenceLength
				|| Math.abs(p1.getStart() - p2.getEnd()) < subsequenceLength)
			overlap = true;

		boolean p1First = false;
		if (p1.getPoint() < p2.getPoint())
			p1First = true;
		// don't consider overlapping pivots
		// if (Math.abs(p1.getEnd()-p2.getStart()) < subsequenceLength )
		// return;

		int available_memory = memoryForWindow - memoryForTree;

		/**
		 * if the point p2 is not in memory--the recent window then we load the
		 * load the block for p2 if necessary
		 */
		if (Math.abs(end - p2.getPoint()) > available_memory) {
			loadBlock(p2);
		}

		float pdist = Memory.distance_Lp_2(p1.getPoint(), p2.getPoint());

		/**
		 * if the distance between two pivots is larger than 2*range, then, no
		 * further join phase is necessary Case 2 in the paper
		 */
		if (pdist > range + p1.getRadii() + p2.getRadii()) {
			// System.out.println("pruned by range+r1+r2 " + range + " "
			// + p1.getRadii() + " " + p2.getRadii());
			return;
		}

		/**
		 * get the vertical vector
		 */
		float[][] diff = difference(p1.getPoint(), p2.getPoint());
		float[][] centor = centor(p1.getPoint(), p2.getPoint());

		float norm = norm(diff);
		/**
		 * get the number of p2
		 */
		int p2_num = p2.getEnd() - p2.getStart() + 1;

		current_count = 0;

		if (pdist + p1.getRadii() + p2.getRadii() < range) {
			// case 1 in the paper
			for (int i = p1.getStart(); i <= p1.getEnd(); i++) {
				/**
				 * exclude overlapping base windows
				 */
				if (overlap) {
					if (!p1First) {
						int leftSlidingWindowEnd = i - subsequenceLength;
						if (leftSlidingWindowEnd < p2.getStart())
							continue;
						else if (leftSlidingWindowEnd >= p2.getEnd())
							buffer[i].addNNCount(p2_num);
						else
							buffer[i].addNNCount(leftSlidingWindowEnd
									- p2.getStart() + 1);
					} else {
						int rightSlidingWindowStart = i + subsequenceLength;
						if (rightSlidingWindowStart >= p2.getEnd())
							continue;
						else if (rightSlidingWindowStart < p2.getStart())
							buffer[i].addNNCount(p2_num);
						else
							buffer[i].addNNCount(p2.getEnd()
									- rightSlidingWindowStart + 1);
					}
				} else {
					buffer[i].addNNCount(p2_num);
				}
			}
			// System.out.println("early pruning");
		} else if (pdist + p2.getRadii() - p1.getRadii() < range) {
			// case 3, 4, 5 in the paper
			List seqs = new Vector();
			for (int i = p1.getStart(); i <= p1.getEnd(); i++) {
				/**
				 * get the distance from every point in p1 to p2
				 */
				double dist = distance_Lp_2(i, p2.getPoint());
				if (dist + p2.getRadii() < range) {
					// Case 3 in the paper
					/**
					 * exclude overlapping base windows
					 */
					if (overlap) {
						if (!p1First) {
							int leftSlidingWindowEnd = i - subsequenceLength;
							if (leftSlidingWindowEnd < p2.getStart())
								continue;
							else if (leftSlidingWindowEnd >= p2.getEnd())
								buffer[i].addNNCount(p2_num);
							else
								buffer[i].addNNCount(leftSlidingWindowEnd
										- p2.getStart() + 1);
						} else {
							int rightSlidingWindowStart = i + subsequenceLength;
							if (rightSlidingWindowStart >= p2.getEnd())
								continue;
							else if (rightSlidingWindowStart < p2.getStart())
								buffer[i].addNNCount(p2_num);
							else
								buffer[i].addNNCount(p2.getEnd()
										- rightSlidingWindowStart + 1);
						}
					} else {
						buffer[i].addNNCount(p2_num);
					}
				} else {
					/**
					 * add subsequence i to the list non pruned
					 */
					seqs.add(new Integer(i));
				}
			}
			int se[] = new int[seqs.size()];
			/**
			 * get the integer list for sequences
			 */
			for (int i = 0; i < seqs.size(); i++) {
				se[i] = ((Integer) seqs.get(i)).intValue();
			}
			/**
			 * calculate the nearest neighbors by Lemma 5
			 */
			// for (int i = 0; i < se.length; i++)
			// System.out.println(se[i]);
			calculateNN(se, p2, diff, centor, norm);
			// System.out.println("unpruned distance computation: "
			// + current_count);
			// } else if (pdist + p1.getRadii() - p2.getRadii() < range) {
			// //System.out.println("in p2 overlap case");
			// // for (int i = p1.getStart(); i <= p1.getEnd(); i++) {
			// // buffer[i].addNNCount(p2_num);
			// // }
		} else if (pdist < p1.getRadii() + p2.getRadii() + range) {
			/**
			 * the number of p1 pivots
			 */
			int num_p1 = p1.getEnd() - p1.getStart() + 1;

			int start = p1.getStart();

			int se[] = new int[num_p1];

			// System.out.println("in the non-overlapping case");
			/**
			 * get the integer list for sequences
			 */
			for (int i = 0; i < num_p1; i++) {
				se[i] = i + start;
			}
			calculateNN(se, p2, diff, centor, norm);
			// System.out.println("unpruned distance computation: " +
			// current_count);
		}
	}

	/**
	 * get the norm of a vector
	 * 
	 * @param values
	 * @return
	 */
	private static float norm(float[][] values) {
		float norm = 0;
		for (int d = 0; d < dimension; d++) {
			for (int i = 0; i < values.length; i++) {
				norm = norm + values[i][d] * values[i][d];
			}
		}
		norm = (float) Math.sqrt((double) norm);
		return norm;
	}

	/**
	 * get the difference
	 * 
	 * @param s1
	 * @param s2
	 * @return
	 */
	private static float[][] difference(int s1, int s2) {
		int start1 = s1 - subsequenceLength + 1;
		int start2 = s2 - subsequenceLength + 1;
		float[][] diff = new float[subsequenceLength][dimension];
		/**
		 * get the difference vector
		 */
		for (int d = 0; d < dimension; d++) {
			for (int i = 0; i < subsequenceLength; i++) {
				diff[i][d] = buffer[start1 + i].getValue()[d]
						- buffer[start2 + i].getValue()[d];
			}
		}
		return diff;
	}

	/**
	 * get the centor between two points
	 * 
	 * @param s1
	 * @param s2
	 * @return
	 */
	private static float[][] centor(int s1, int s2) {
		int start1 = s1 - subsequenceLength + 1;
		int start2 = s2 - subsequenceLength + 1;
		float[][] centor = new float[subsequenceLength][];
		// int dim = buffer[start1].getValue().length;
		/**
		 * get the difference vector
		 */
		for (int i = 0; i < subsequenceLength; i++) {
			centor[i] = new float[dimension];
			for (int d = 0; d < dimension; d++) {
				centor[i][d] = (buffer[start1 + i].getValue()[d] + buffer[start2
						+ i].getValue()[d]) / 2;
			}
		}
		return centor;
	}

	/**
	 * get the vertical distance between a point and the plane
	 * 
	 * @param s
	 * @param diff
	 * @param centor
	 * @param norm
	 * @return
	 */
	private static float getVerticalDist(int s, float[][] diff,
			float[][] centor, float norm) {
		int start = s - subsequenceLength + 1;
		float dist = 0;
		/**
		 * the distance between a point and the vertical plane
		 */
		for (int d = 0; d < dimension; d++) {
			for (int i = 0; i < subsequenceLength; i++) {
				dist = dist + diff[i][d]
						* (buffer[i + start].getValue()[d] - centor[i][d]);
				// System.out.println("diff" + diff[i - start]);
				// System.out.println("centor" + centor[i - start]);
				// System.out.println(diff[i - start]
				// * (buffer[i].getValue() - centor[i - start]));
			}
		}

		// System.out.println(dist);
		/**
		 * get the distance
		 */
		dist = Math.abs(dist) / norm;
		// if (dist == 0) {
		// System.out.println();
		// System.out.println(dist);
		// }
		return dist;
	}

	/**
	 * calculate the range neighbor
	 * 
	 * @param seqs
	 * @param p2
	 * @param diff
	 * @param centor
	 * @param norm
	 */
	private static void calculateNN(int[] seqs, Pivot p2, float diff[][],
			float[][] centor, float norm) {
		/**
		 * if two balls do not overlap calculate each point's distance to the
		 * vertical plane
		 */
		float dist1[] = new float[seqs.length];
		int num_p2 = p2.getEnd() - p2.getStart() + 1;
		int start2 = p2.getStart();
		/**
		 * new the dist2 array
		 */
		float dist2[] = new float[num_p2];

		/**
		 * get the vertical distance for dist1
		 */
		for (int i = 0; i < seqs.length; i++) {
			dist1[i] = getVerticalDist(seqs[i], diff, centor, norm);
			// System.out.println(dist1[i]);
		}
		/**
		 * get the vertical distance for p2
		 */
		// System.out.println(num_p2);
		int s = p2.getStart();
		for (int i = p2.getStart(); i <= p2.getEnd(); i++) {
			dist2[i - s] = getVerticalDist(i, diff, centor, norm);
		}

		/**
		 * join the subsequences
		 */
		for (int i = 0; i < dist1.length; i++) {
			for (int j = 0; j < dist2.length; j++) {
				/**
				 * if can not be pruned it has to be joined
				 */
				// System.out.println(dist1[i]+" " +dist2[i]+" "
				// +range);
				if (dist1[i] + dist2[j] < range) {
					current_count++;
					subsequenceJoin(seqs[i], start2 + j, range);
					// System.out.println("subsequence join with range "+
					// range);
				} else {
					// System.out.println("pruned");
					// computation is pruned
				}
			}
		}
	}

	public static float[][] getDWTCoefficients(float[][] data) {
		float input[][] = new float[data.length][dimension];
		for (int i = 0; i < data.length; i++)
			for (int d = 0; d < dimension; d++)
				input[i][d] = data[i][d];

		// WARNING: This will destroy the contents of the input array
		// This function assumes input.length=2^n, n>1
		float[][] output = new float[input.length][dimension];

		for (int d = 0; d < dimension; d++) {
			for (int length = input.length >> 1; length > 0; length >>= 1) {
				// length=2^n, WITH DECREASING n
				for (int i = 0; i < length; i++) {
					float sum = (input[i * 2][d] + input[i * 2 + 1][d]) / 2;
					float difference = (input[i * 2][d] - input[i * 2 + 1][d]) / 2;
					output[i][d] = sum;
					output[length + i][d] = difference;
				}
				if (length == 1)
					break;

				int size = length << 1;
				for (int s = 0; s < size; s++)
					input[s][d] = output[s][d];
				// Swap arrays to do next iteration
				// System.arraycopy(output[][d], 0, input[][d], 0, length << 1);
			}
		}

		return output;
	}

	public static float[][] cutCoefficients(float coeff[][], int dim) {
		float result[][] = new float[dim][dimension];
		for (int d = 0; d < dimension; d++) {
			for (int i = 0; i < dim; i++)
				result[i][d] = coeff[i][d];
		}
		return result;
	}

	/**
	 * initialize DWT coefficients
	 * 
	 * @param dim
	 * @return
	 */
	public static float[][][] initializeDWT(int dim, int length) {
		float dwt[][][] = new float[length][][];
		float data[][] = new float[subsequenceLength][dimension];

		for (int i = subsequenceLength - 1; i < length; i++) {
			int start = i - subsequenceLength + 1;
			for (int j = 0; j < subsequenceLength; j++) {
				for (int d = 0; d < dimension; d++) {
					data[j][d] = buffer[start + j].getValue()[d];
				}
			}
			float[][] temporary = getDWTCoefficients(data);
			dwt[i%length] = Memory.cutCoefficients(temporary, dim);
			// if (i % 10000 == 0)
			// System.out.println("in initialize " + i);
		}
		/**
		 * set the dwt series in memory
		 */
		Memory.dwtWindow = dwt;
		return dwt;
	}

	public static void cycleDWT(int slidingWindowEnd, int dim) {
		float[][] data = new float[subsequenceLength][dimension];
		int start = slidingWindowEnd - subsequenceLength + 1;
		for (int j = 0; j < subsequenceLength; j++) {
			for (int d = 0; d < dimension; d++) {
				data[j][d] = buffer[start + j].getValue()[d];
			}
		}
		float[][] temporary = getDWTCoefficients(data);
		float dwt[][] = Memory.cutCoefficients(temporary, dim);
		Memory.dwtWindow[slidingWindowEnd % Memory.dwtWindow.length] = dwt;
		//if (slidingWindowEnd % 10000 == 0)
		//	System.gc();
	}

	/**
	 * join two subsequnces, only increase s1's nnCount
	 * 
	 * @param s1
	 *            the active join subsequence
	 * @param s2
	 *            the passive join subsequence
	 */
	public static void subsequenceJoinDWT(int s1, int s2, float range) {
		if (Math.abs(s1 - s2) < subsequenceLength)
			return;

		float dist_LB = Memory.distance_Lp_2_DWT(s1, s2);

		// System.out.println("LB:" + dist_LB);

		if (dist_LB < range) {
			//System.out.println("non pruned " + s1);
			float dist = Memory.distance_Lp_2(s1, s2);
			// System.out.println("Dist:" + dist);
			/**
			 * if dist(s1,s2)<range return directly
			 */
			if (dist < range) {
				// if (s1 == 1085) {
				// System.out.println("Join 1085 with " + s2 + " successfully");
				// Memory.log.println("Join 1085 with " + s2 + " successfully");
				// }
				Memory.buffer[s1].increaseNNCount();
			}
		}
	}

	public static long distance_computation_DWT = 0;

	public static float distance_Lp_2_DWT(int s1, int s2) {
		distance_computation_DWT++;
		float[][] data_1 = Memory.dwtWindow[s1 % dwtWindow.length];
		float[][] data_2 = Memory.dwtWindow[s2 % dwtWindow.length];

		float aggregation = 0;
		// aggregate lowerbound distance from each dimension
		for (int d = 0; d < dimension; d++) {
			float D[][] = new float[data_1.length][dimension];
			for (int i = 0; i < D.length; i++)
				D[i][d] = data_1[i][d] - data_2[i][d];
			float square = D[0][d] * D[0][d];
			int current = 1;
			//int iteration = (int)(Math.log(subsequenceLength+1)/Math.log(2));
			//int pass = 0;
			while (current < subsequenceLength) {
				//pass++;
				int start = current;
				int end = 2 * current - 1;
				/**
				 * it the value is not padded
				 */
				if (end < data_1.length) {
					for (int j = start; j <= end; j++)
						square += D[j][d] * D[j][d];
				}
				//else
				//{
				//	square = square * (float)Math.pow(
				//			(double)2, (double)(iteration-pass+1));
				//	break;
				//}
				square *= 2;
				current *= 2;
			}

			aggregation += square;
		}
		return (float) Math.sqrt((double) aggregation);
	}
}
