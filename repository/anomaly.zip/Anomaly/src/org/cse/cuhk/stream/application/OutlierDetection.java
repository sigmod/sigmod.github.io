package org.cse.cuhk.stream.application;

import java.io.PrintWriter;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The interface is for outlier detection
 * 
 */
public interface OutlierDetection {

	/**
	 * sliding the whole window
	 * 
	 */
	public void keepSliding();

	public PrintWriter getLog();

	public boolean isStop(Pivot p);

	public int getSlidingWindowEnd();

	public float getRange();
}
