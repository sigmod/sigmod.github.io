package org.cse.cuhk.stream.application;

public class Candidate implements Comparable{

	private Pivot pivot = null;

	public float distance = 0;

	public Candidate(Pivot p, float d) {
		pivot = p;
		distance = d;
	}

	public float getDistance() {
		return distance;
	}

	public Pivot getPivot() {
		return pivot;
	}

	public int compareTo(Object o) {
		Candidate bl = (Candidate) o;
		if (this.distance < bl.getDistance())
			return -1;
		if (this.distance == bl.getDistance())
			return 0;
		if (this.distance > bl.getDistance())
			return 1;
		else
			return -1;
	}
}
