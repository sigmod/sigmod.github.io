package org.cse.cuhk.stream;


/**
 * 
 *            Database & Data Mining Group
 *	Department of Computer Science & Engineering 
 *         The Chinese University of Hong Kong
 *
 * 		   Copyright@2006 CSE
 *
 *           @author  Yingyi Bu
 *
 *	this interface contains some constants for other object to use
 */
public interface StreamConstants {

	/**
	 * this constant means the requester is client consuming context
	 */
	public static final int CLIENT = 0;
	
	/**
	 * this constant means the requester is context provider
	 */
	public static final int PROVIDER = 1;
	
	/**
	 * this constant means the client is registering his interesting contexts
	 */
	public static final int REGISTER = 2;
	
	/**
	 * this constant means the client is deregistering his interesting contexts
	 */
	public static final int DEREGISTER = 3;
	
	/**
	 * this constant points out the system properties file
	 */
	public static final String SYSTEM_PROPERTIES = "contextlibrary.properties";
}
