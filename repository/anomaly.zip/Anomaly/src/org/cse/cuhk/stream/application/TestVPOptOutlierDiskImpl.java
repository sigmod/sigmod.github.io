package org.cse.cuhk.stream.application;

public class TestVPOptOutlierDiskImpl {

	/*
	 * Test method for
	 * 'org.cse.cuhk.stream.application.OutlierDetectionImpl.onAppending(Point)'
	 */
	public static void testOnAppending() {

		OutlierDetectionVPTreeReorderImpl detect = new OutlierDetectionVPTreeReorderImpl();
		// detect.test();
		int window = detect.initialWindow();
		detect.keepSliding();

		Memory.free();
		Memory.clearIOcost();
		System.setProperty("SlidingWindowSize", new Integer(window).toString());

		/**
		 * random vp-trees
		 */
		Memory.free();
		Memory.clearIOcost();
		OutlierDetection det = new OutlierDetectionPivotBFImpl();
		det.keepSliding();
	}

	public static void main(String[] args) {
		Memory.initializeSystemProperties();
		Memory.dataFile = "altitude.dat";
		testOnAppending();
	}

}
