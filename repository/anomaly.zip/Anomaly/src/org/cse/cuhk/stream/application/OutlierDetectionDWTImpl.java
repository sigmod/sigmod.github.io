package org.cse.cuhk.stream.application;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class is to implement the outlier detection interface
 */

public class OutlierDetectionDWTImpl implements OutlierDetection {

	/**
	 * the size of the buffer
	 */
	private int bufferSize = 0;

	/**
	 * the length of subsequence, which is fixed by algorithm parameter
	 */
	private int subsequenceLength = 0;

	/**
	 * the range d of k-d outlier definition
	 */
	private double range = 0.0;

	/**
	 * the parameter k of k-d outlier
	 */
	private int K = 0;

	/**
	 * the start of the sliding window
	 */
	private int slidingWindowStart = 0;

	/**
	 * the end of the sliding window
	 */
	private int slidingWindowEnd = 0;

	/**
	 * the size of sliding window
	 */
	private int slidingWindowSize = 0;

	private int dim =2;

	/**
	 * the default constructor
	 * 
	 */
	public OutlierDetectionDWTImpl() {

		try {
			/**
			 * new the log object
			 */
			Memory.log = new PrintWriter(new OutputStreamWriter(
					new FileOutputStream("log/" + Memory.dataFile
							+ "-DWT-bf.log")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		/**
		 * initialize buffer size
		 */
		bufferSize = Integer.parseInt(System.getProperty("BufferSize"));
		/**
		 * the parameter of k-d outlier
		 */
		K = Integer.parseInt(System.getProperty("K"));

		/**
		 * intialize the subsequence length
		 */
		subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));

		/**
		 * intialize the size of sliding window
		 */
		slidingWindowSize = Integer.parseInt(System
				.getProperty("SlidingWindowSize"));

		Memory.loadData();
		
		Memory.initializeDWT(dim, slidingWindowSize);
		/**
		 * the range d for k-d outlier
		 */
		range = Memory.calculateRange();

	}

	/**
	 * keep the window sliding continuously
	 * 
	 */
	public void keepSliding() {
		/**
		 * set up the start and end of sliding window
		 */
		this.initialWindow();
		/**
		 * start to sliding the window
		 */
		int start = this.slidingWindowEnd + 1;
		long begin = System.currentTimeMillis();
		Memory.clearDistanceCounter();
		Memory.clearBlockAccess();
		for (int i = start; i < this.bufferSize; i++) {
			this.onSliding();
		}
		long end = System.currentTimeMillis();
		/**
		 * print the total time
		 */
		System.out.println("Total time: " + (end - begin));
		Memory.log.println("Total time: " + (end - begin));
		Memory.log
				.println("Total Distance Computation: "
						+ (Memory.getDistanceComputation() + Memory.distance_computation_DWT
								* dim / Memory.subsequenceLength));
		Memory.log.println("Window Size: "
				+ (slidingWindowEnd - slidingWindowStart));
		Memory.log.println("Slide Steps: " + (bufferSize - start));
		Memory.clearDistanceCounter();
		Memory.clearBlockAccess();
		Memory.log.flush();
	}

	/**
	 * intialize the slding window, calculate pivots
	 * 
	 */
	private void initialWindow() {
		/**
		 * set up the parameters of Sliding Window
		 */
		slidingWindowStart = subsequenceLength - 1;
		slidingWindowEnd = slidingWindowSize-1;
		//for (int i = slidingWindowStart; i <= slidingWindowEnd; i++) {
		//	for (int j = slidingWindowStart; j < i; j++) {
		//		Memory.subsequenceJoinDWT(i, j, (float) range);
		//		if (isStop(i))
		//			break;
		//	}
		//	if(i%20000==0)
		//		System.out.println(i);
		//}
	}

	/**
	 * sliding the sliding widnow for 1 step
	 * 
	 */
	public void onSliding() {
		// TODO Auto-generated method stub
		/**
		 * reporting if the start of sliding window is an outlier
		 */
		judgeOldestOutlier(slidingWindowStart);
		
		this.slidingWindowEnd++;
		/**
		 * remove the start position of the sliding window
		 */
		slidingWindowStart++;;
		
		Memory.cycleDWT(slidingWindowEnd, dim);
		
		/**
		 * do the range query on the left sliding window
		 */
		this.calculateRangeQuery(slidingWindowEnd);
	}

	/**
	 * execute similarity range query over the sliding window along the left
	 * direction, thus the distance matrix needing to be updated
	 * 
	 * @param pivot
	 */
	private void calculateRangeQuery(int position) {
		/**
		 * search in the left sliding window
		 */
		for (int i = slidingWindowEnd-1; i > slidingWindowStart; i--) {
			/**
			 * the interval is less than subsequence length
			 */
			Memory.subsequenceJoinDWT(position, i, (float) range);
			if (isStop(position))
				break;
		}
		
		if(position%20000==0)
			System.out.println(position);
	}

	/**
	 * 
	 * @param pivot
	 * @return
	 */
	public boolean isStop(int position) {

		// System.out.println(position);
		if (Memory.buffer == null) {
			System.out.println("buffer null");
		}
		if (Memory.buffer[position].getNNCount() >= K)
			return true;
		else
			return false;
	}

	public boolean isStop(Pivot pivot) {
		return false;
	}

	/**
	 * judge if the oldest subsequence is an outlier
	 * 
	 * @param position
	 */
	private void judgeOldestOutlier(int position) {
		if (Memory.buffer[position].getNNCount() >= K)
			return;
		this.calculateRangeQuery(position);
		if (Memory.buffer[position].getNNCount() >= K)
			return;
		/**
		 * report outlier
		 */
		boolean isFind = false;
		for (int i = position; i >= subsequenceLength - 1
				&& i > position - subsequenceLength; i--) {
			if (Memory.buffer[i].isOutlier()) {
				isFind = true;
				break;
			}
		}
		if (isFind == false) {
			Memory.buffer[position].markOultier();
			System.out.println("finding outlier at " + position);
			Memory.log.println("finding outlier at " + position);
			Memory.log.flush();
		}
	}

	/**
	 * remove the oldest subsequences and the oldest tree if necessary
	 * 
	 * @param position
	 */
	private void removeOldest() {
		/**
		 * slide the start of window
		 */
		slidingWindowStart++;
	}

	/**
	 * empty method for the interface
	 */
	public void pivotJoin(Pivot p1, Pivot p2) {

	}

	public PrintWriter getLog() {
		return Memory.log;
	}

	public int getSlidingWindowEnd() {
		return this.slidingWindowEnd;
	}

	public float getRange() {
		return (float) range;
	}

}
