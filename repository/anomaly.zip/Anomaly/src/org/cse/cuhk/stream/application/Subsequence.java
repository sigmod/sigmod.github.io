package org.cse.cuhk.stream.application;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * 
 * This class is of subsequences that for indexing
 * 
 */
public class Subsequence {

	private boolean isOutlier = false;

	/**
	 * count of its range nearest neighbors
	 * TODO: further optimization could be taken to 
	 * remove this parameter, e.g, use a certain pool
	 * to keep necesary nnCount
	 */
	private int nnCount = 0;

	/**
	 * the values of this point:  a m-dimensional vector
	 * 3-D of a trajectory point
	 */
	private float value[] = null;

	/**
	 * empty constructor
	 * 
	 */
	public Subsequence() {

	}

	/**
	 * parametered constructor
	 * 
	 * @param v
	 *            the value of this point
	 */
	public Subsequence(float[] v) {
		value = v;
	}

	/**
	 * get the value of ending point of this subsequnce
	 * 
	 * @return the vlaue of ending point of this subsequence
	 */
	public float[] getValue() {
		return value;
	}

	/**
	 * set the value of ending point of this subsequence
	 * 
	 * @param v
	 *            the value
	 */
	public void setValue(float v[]) {
		value = v;
	}

	/**
	 * set the number
	 * 
	 * @param n
	 */
	public void setNNCount(int n) {
		nnCount = n;
	}

	/**
	 * increase the number nearest neighbor count of this subsequence
	 * 
	 */
	public void increaseNNCount() {
		nnCount++;
	}

	public void addNNCount(int a) {
		nnCount = nnCount + a;
	}

	/**
	 * @return the number of range nearest neighbors
	 */
	public int getNNCount() {
		return nnCount;
	}

	/**
	 * mark the subsequence as outlier
	 * 
	 */
	public void markOultier() {
		isOutlier = true;
	}

	/**
	 * return if the subsequence is an outlier
	 * 
	 * @return the variable isOutlier
	 */
	public boolean isOutlier() {
		return isOutlier;
	}
}
