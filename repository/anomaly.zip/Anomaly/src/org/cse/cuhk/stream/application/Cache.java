package org.cse.cuhk.stream.application;

public class Cache {

	public int start = 0;

	public int end = 0;

	public Cache(int s, int e) {
		start = s;
		end = e;
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}
}
