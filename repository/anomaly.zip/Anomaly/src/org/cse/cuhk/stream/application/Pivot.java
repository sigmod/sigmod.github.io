package org.cse.cuhk.stream.application;


/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class pivot is the centroid of temporal local clusters/partitions
 * 
 */
public class Pivot extends Object implements Cloneable {

	private float radii = 0;

	//private Cluster cluster = null;

	/**
	 * set the right most searched to be 0
	 */
	private int rightMost = 0;

	/**
	 * the ending position of pivot subsequence
	 */
	private int point = 0;

	/**
	 * the ending position of start subsequence under this pivot
	 */
	private int start = 0;

	/**
	 * the ending position of ending subsequence under this pivot
	 */
	private int end = 0;

	/**
	 * the number of half-range nearest neighbors
	 */
	private int num_half_range_neighbors = 0;

	/**
	 * defaultly we search the left first, then we search the right part of the
	 * pivot subsequence
	 */
	private boolean searchedRight = false;

	/**
	 * the constructor with pivot point only
	 * 
	 * @param p
	 *            the ending position of pivot subsequnce
	 */
	public Pivot(int p) {
		super();
		point = p;
		rightMost = p;
	}

	/**
	 * the constructor with pivot point, start point, and ending point
	 * 
	 * @param p
	 *            the ending position of pivot subsequence
	 * @param s
	 *            the ending position of starting subsequence under pivot
	 *            subsequence
	 * @param e
	 *            the ending position of ending subsequence under pivot
	 *            subsequence
	 */
	public Pivot(int p, int s, int e) {
		point = p;
		start = s;
		end = e;
		rightMost = p;
	}

	/**
	 * set isFullSearch to be true
	 * 
	 */
	public void setSearchRight() {
		searchedRight = true;
	}

	/**
	 * set the right most position this pivot joined with
	 * 
	 * @position the right most position searched, and joined with current pivot
	 */
	public void setRightMostSearch(int position) {
		rightMost = position;
	}

	/**
	 * get the right most searched position
	 * 
	 * @return the right most searched position
	 */
	public int getRightMostSearch() {
		return rightMost;
	}

	/**
	 * 
	 * @return isFullSearch
	 */
	public boolean getSearchedRight() {
		return searchedRight;
	}

	/**
	 * 
	 * @param s
	 *            set the start position of this pivot
	 */
	public void setStart(int s) {
		start = s;
	}

	/**
	 * 
	 * @param e
	 *            set the ending position of this pivot
	 */
	public void setEnd(int e) {
		end = e;
	}

	/**
	 * 
	 * @return the point of pivot
	 */
	public int getPoint() {
		return point;
	}

	/**
	 * 
	 * @return the start position covered by this pivot
	 */
	public int getStart() {
		return start;
	}

	/**
	 * increase the number of half range neighbors
	 * 
	 */
	public void increase_half_range_neighbors() {
		this.num_half_range_neighbors++;
	}

	/**
	 * 
	 * @return the number of half range nearest neighbors
	 */
	public int get_num_half_range_neighbors() {
		return num_half_range_neighbors;
	}

	/**
	 * 
	 * @return the ending position covered by this pivot
	 */
	public int getEnd() {
		return end;
	}

	/**
	 * the inherite implemenation of clone
	 */
	public Object clone() {
		Pivot p = new Pivot(point, start, end);
		p.num_half_range_neighbors = num_half_range_neighbors;
		p.rightMost = rightMost;
		p.searchedRight = searchedRight;
		return p;
	}

	/**
	 * get the dimensionality of the point
	 */
	public int getDimension() {
		int dim = Integer.parseInt(System.getProperty("SubsequenceLength"));
		return dim;
	}

	/**
	 * return the ith entry's value of the pivot
	 */
	public float[] getFloatCoordinate(int i) {
		int subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));
		return  Memory.buffer[this.point - subsequenceLength + i + 1]
				.getValue();
	}

	/**
	 * the to string method print the subsequence ending at point
	 */
	public String toString() {
		int subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));
		int begin = this.point - subsequenceLength + 1;
		String s = "(" + Memory.buffer[begin];

		for (int i = begin + 1; i <= point; i++) {
			s += ", " + Memory.buffer[i];
		}

		return s + ")";
	}

	/**
	 * justify if the two points are equal
	 */
	public boolean equals(Object p) {
		if (!(p instanceof Pivot))
			return false;
		boolean equal = true;
		Pivot piv = (Pivot) p;
		/**
		 * see if the two pivots are equal on every dimension
		 */
		for (int i = 0; i < this.getDimension(); i++) {
			float[] v1 = getFloatCoordinate(i);
			float[] v2 = piv.getFloatCoordinate(i);
			if (!isEqual(v1, v2)) {
				equal = false;
				break;
			}
		}
		return equal;
	}
	
	/**
	 * determine whether the two vectors have the same content
	 * @param v1
	 * @param v2
	 * @return
	 */
	private boolean isEqual(float[] v1, float[] v2)
	{
		if(v1.length!=v2.length)
		{
			System.out.println("dimension error!");
			return false;
		}
		for(int i=0; i<v1.length; i++)
			if(v1[i]!=v2[i])
				return false;
		return true;
	}

	public void setRadii(float r) {
		radii = r;
	}

	/**
	 * return the radius of the pivot
	 * 
	 * @return
	 */
	public float getRadii() {
		return radii;
	}

	/**
	 * 
	 * @param pivot
	 * @return
	 */
	public boolean isStop() {
		int K = Integer.parseInt(System.getProperty("K"));
		if (this.get_num_half_range_neighbors() >= K) {
			return true;
		}
		/**
		 * if every element in the pivot's bin is not outlier, then the search
		 * could be breaked
		 */
		boolean impossible = true;
		for (int j = this.getStart(); j <= this.getEnd(); j++) {
			if (Memory.buffer[j].getNNCount() < K)
				impossible = false;
		}
		return impossible;
	}
}
