package org.cse.cuhk.stream.application;

import java.io.File;

public class TestAllImpl {

	/*
	 * Test method for
	 * 'org.cse.cuhk.stream.application.OutlierDetectionImpl.onAppending(Point)'
	 */
	public static void testOnAppending() {

		String destDir = "data";
		File directory = new File(destDir);
		File[] files = directory.listFiles();

		for (int i = 0; i < files.length; i++) {
			Memory.dataFile = files[i].getName();

			/**
			 * vp tree reschedule
			 */
			OutlierDetection det = new OutlierDetectionVPTreeReorderImpl();
			det.keepSliding();

			Memory.free();
			Memory.clearIOcost();
			System.gc();

			det = new OutlierDetectionPivotBFImpl();
			det.keepSliding();
			Memory.free();
			Memory.clearIOcost();
			System.gc();
			

			det = new OutlierDetectionDWTImpl();
			det.keepSliding();
			Memory.free();
			Memory.clearIOcost();
			System.gc();
			//			
			//			
			det = new OutlierDetectionBFImpl();
			det.keepSliding();
			Memory.free();
			Memory.clearIOcost();
			System.gc();
		}
	}

	public static void main(String[] args) {
		Memory.initializeSystemProperties();
		testOnAppending();
	}
}
