package org.cse.cuhk.stream.application;

public class TestPivotBFOutlierImpl {

	/*
	 * Test method for
	 * 'org.cse.cuhk.stream.application.OutlierDetectionBFImpl.keepSliding()'
	 */
	public static void testKeepSliding() {
		OutlierDetection detect = new OutlierDetectionPivotBFImpl();
		detect.keepSliding();
	}

	public static void main(String[] args) {
		Memory.initializeSystemProperties();
		Memory.dataFile = "altitude.dat";
		testKeepSliding();
	}
}
