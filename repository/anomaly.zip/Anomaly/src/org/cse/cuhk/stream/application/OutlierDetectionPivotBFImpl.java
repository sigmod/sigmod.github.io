package org.cse.cuhk.stream.application;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.Vector;

/**
 * 
 * 
 * Database & Data Mining Group Department of Computer Science & Engineering The
 * Chinese University of Hong Kong
 * 
 * Copyright@2006 CSE
 * 
 * @author Yingyi Bu
 * 
 * The class is to implement the outlier detection interface
 */

public class OutlierDetectionPivotBFImpl implements OutlierDetection {

	/**
	 * the size of the buffer
	 */
	private int bufferSize = 0;

	/**
	 * the length of subsequence, which is fixed by algorithm parameter
	 */
	private int subsequenceLength = 0;

	/**
	 * the point to current pivot
	 */
	private Pivot current_pivot = null;

	/**
	 * current status, is to extend pivot or not
	 */
	private boolean isExtend = true;

	/**
	 * the range d of k-d outlier definition
	 */
	private float range = 0;

	/**
	 * the half of the parameter range d
	 */
	private float half_range = 0;

	/**
	 * the max size of left bin or right bin
	 */
	private int binMaxSize = 0;

	/**
	 * the parameter k of k-d outlier
	 */
	private int K = 0;

	/**
	 * the start of the sliding window
	 */
	private int slidingWindowStart = 0;

	/**
	 * the end of the sliding window
	 */
	private int slidingWindowEnd = 0;

	/**
	 * the size of sliding window
	 */
	private int slidingWindowSize = 0;

	/**
	 * all the current pivots in this list
	 */
	private List pivots = new Vector();

	/**
	 * the default constructor
	 * 
	 */
	public OutlierDetectionPivotBFImpl() {

		try {
			/**
			 * new the log object
			 */
			Memory.log = new PrintWriter(new OutputStreamWriter(
					new FileOutputStream("log/" + Memory.dataFile
							+ "-running-pivot-bf.log")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		/**
		 * initialize buffer size
		 */
		bufferSize = Integer.parseInt(System.getProperty("BufferSize"));

		/**
		 * initialize the size of sliding window
		 */
		slidingWindowSize = Integer.parseInt(System
				.getProperty("SlidingWindowSize"));

		/**
		 * the parameter of k-d outlier
		 */
		K = Integer.parseInt(System.getProperty("K"));

		/**
		 * intialize the subsequence length
		 */
		subsequenceLength = Integer.parseInt(System
				.getProperty("SubsequenceLength"));

		/**
		 * the max size of a bin, intialize to half subsequence length
		 */
		binMaxSize = subsequenceLength * 2;

		Memory.loadData();
		/**
		 * the range d for k-d outlier
		 */
		range = Memory.calculateRange();
	}

	/**
	 * keep the window sliding continuously
	 * 
	 */
	public void keepSliding() {
		this.initialWindow();
		Memory.log.flush();
		/**
		 * start to sliding the window
		 */
		int start = this.slidingWindowEnd + 1;
		long begin = System.currentTimeMillis();
		Memory.clearDistanceCounter();
		Memory.clearIOcost();
		Memory.memoryForTree = 0;
		for (int i = start; i < this.bufferSize; i++) {
			this.onSliding();
			// System.out.println("memory size: " + Memory.memoryForWindow);
		}
		long end = System.currentTimeMillis();
		System.out.println("Total time: " + (end - begin));
		Memory.log.println("Total time: " + (end - begin));
		Memory.log.println("Total Distance Computation: "
				+ Memory.getDistanceComputation());
		Memory.log.println("Window Size: "
				+ (slidingWindowEnd - slidingWindowStart));
		Memory.log.println("Slide Steps: " + (bufferSize - start));
		Memory.log.println("IO Cost: " + Memory.getBlockAccess());
		Memory.log.println("pivot size " + 4 * pivots.size());
		Memory.log.flush();
	}

	/**
	 * intialize the slding window, calculate pivots
	 * 
	 */
	private void initialWindow() {
		this.isExtend = true;
		slidingWindowStart = this.subsequenceLength - 1;
		current_pivot = null;
		this.half_range = range / 2;
		// List sameTreePivots = new Vector();
		/**
		 * set up the parameters of Sliding Window
		 */
		slidingWindowEnd = subsequenceLength + this.slidingWindowSize - 1;
		for (int i = this.slidingWindowStart; i <= slidingWindowEnd; i++) {
			calculatePivot(i);
		}

		slidingWindowStart = subsequenceLength - 1;
	}

	private float current_radii = 0;

	/**
	 * initlize pivots, list and trees
	 * 
	 * @param position
	 * @param pivots
	 */
	private void calculatePivot(int position) {
		/**
		 * if in the extending phase
		 */
		if (isExtend) {
			int start = subsequenceLength - 1;
			if (current_pivot != null)
				start = current_pivot.getEnd() + 1;

			boolean isIn = true;
			for (int i = start; i < position; i++) {
				float dist = Memory.distance_Lp_2(i, position);
				if (dist > this.half_range) {
					isIn = false;
					break;
				}
				if (dist < this.half_range && dist > current_radii) {
					current_radii = dist;
				}
			}
			if (isIn == false || position - start > this.binMaxSize) {
				/**
				 * set up a new pivot
				 */
				Pivot temp = new Pivot(position - 1);
				current_pivot = temp;
				current_pivot.setStart(start);
				current_pivot.setEnd(position - 1);
				// System.out.println("find pivot " + pivots.size() + " "
				// + position + " in pivot brute force");
				/**
				 * set the pivot of every subsequence covered by current pivot
				 */
				// for (int j = start; j < position; j++) {
				// Memory.buffer[j].setPivot(current_pivot);
				// }
				isExtend = false;
			}
		}
		if (isExtend == false) {
			/**
			 * is not in the extending phase
			 */
			int point = current_pivot.getPoint();
			float dist = Memory.distance_Lp_2(point, position);
			/**
			 * set the subsequence's pivot value
			 */
			if (dist < this.half_range && position - point < this.binMaxSize) {
				// Memory.buffer[position].setPivot(current_pivot);
				if (dist < this.half_range && dist > current_radii) {
					current_radii = dist;
				}
			} else {
				isExtend = true;
				/**
				 * set the end of current pivot
				 */
				current_pivot.setEnd(position - 1);
				/**
				 * calculate the query
				 */
				calculatePivotRangeQuery(current_pivot);

				current_pivot.setRadii(current_radii);

				current_radii = 0;
				/**
				 * insert pivot into list
				 */
				pivots.add(current_pivot);
			}
		}

	}

	/**
	 * sliding the sliding widnow for 1 step
	 * 
	 */
	public void onSliding() {
		// TODO Auto-generated method stub
		this.slidingWindowEnd++;
		/**
		 * calculate pivot position based on new coming data value
		 */
		if (this.slidingWindowEnd < this.bufferSize)
			calculatePivot(slidingWindowEnd);
		/**
		 * reporting if the start of sliding window is an outlier //
		 */
		judgeOldestOutlier(slidingWindowStart);

		/**
		 * remove the start position of the sliding window
		 */
		removeOldest(slidingWindowStart);
	}

	/**
	 * execute similarity range query over the sliding window along the left
	 * direction, thus the distance matrix needing to be updated
	 * 
	 * @param pivot
	 */
	private void calculatePivotRangeQuery(Pivot pivot) {
		/**
		 * join pivots in the pivot List //
		 */
		for (int i = 0; i < pivots.size(); i++) {
			Pivot comparingPivot = (Pivot) pivots.get(i);
			if (pivot != comparingPivot)
				Memory.joinPivots(pivot, comparingPivot, this.slidingWindowEnd,
						range);
			if (isStop(pivot))
				break;
		}
	}

	/**
	 * 
	 * @param pivot
	 * @return
	 */
	public boolean isStop(Pivot pivot) {
		if (pivot.get_num_half_range_neighbors() > K) {
			return true;
		}
		/**
		 * if every element in the pivot's bin is not outlier, then the search
		 * could be breaked
		 */
		boolean impossible = true;
		for (int j = pivot.getStart(); j <= pivot.getEnd(); j++) {
			if (Memory.buffer[j].getNNCount() <= K)
				impossible = false;
		}
		return impossible;
	}

	/**
	 * judge if the oldest subsequence is an outlier
	 * 
	 * @param position
	 */
	private int judgeOldestOutlier(int position) {
		// Pivot piv = Memory.buffer[position].getPivot();

		Pivot piv = (Pivot) pivots.get(0);
		if (!(piv.getStart() <= position && piv.getEnd() >= position))
			getLog().println(" pivots error!!! ");
		/**
		 * if position is not outlier, nothing to be done
		 */
		if (Memory.buffer[position].getNNCount() >= this.K)
			return -1;
		/**
		 * if the right part is not searched
		 */
		if (!piv.getSearchedRight()) {
			/**
			 * if the pivot is not searched on the right direction search the
			 * right first
			 */
			this.calculatePivotRangeQuery(piv);
			/**
			 * set right to be searched
			 */
			piv.setSearchRight();
			/**
			 * set the right most position searched
			 */
			// int rightMost = 0;
			/**
			 * if position is not outlier, nothing to be done
			 */
			if (Memory.buffer[position].getNNCount() >= this.K)
				return -1;
		}

		/**
		 * if not outlier, return
		 */
		if (Memory.buffer[position].getNNCount() >= this.K)
			return -1;

		/**
		 * report outlier
		 */
		boolean isFind = false;
		for (int i = position; i >= subsequenceLength - 1
				&& i > position - subsequenceLength; i--) {
			if (Memory.buffer[i].isOutlier()) {
				isFind = true;
				break;
			}
		}
		if (isFind == false) {
			Memory.buffer[position].markOultier();
			System.out.println("finding outlier at " + position + " NN "
					+ Memory.buffer[position].getNNCount() + "  K " + K);
			Memory.log.println("finding outlier at " + position + " NN "
					+ Memory.buffer[position].getNNCount() + "  K " + K);
			Memory.log.flush();
		}
		return position;
	}

	/**
	 * remove the oldest subsequences and the oldest pivot if necessary
	 * 
	 * @param position
	 */
	private void removeOldest(int position) {
		// get the oldest pivot
		Pivot p = (Pivot) pivots.get(0);
		if (!(position <= p.getEnd() && position >= p.getStart()))
			getLog().println("pivot error");
		/**
		 * if the oldest one is not a pivot and in its right bin change its
		 * pivot's start the pivot might become a virtual pivot
		 */
		if (position < p.getEnd()) {
			p.setStart(position + 1);
		}
		/**
		 * reach the end of a pivot, the pivot is of no use since then
		 */
		if (position == p.getEnd()) {
			/**
			 * the removing position is a pivot then change current piece window
			 * delete the oldest pivot and remove it from current piece window
			 */
			// if (pivots.size() > 0)
			pivots.remove(0);
		}
		this.slidingWindowStart++;
	}

	public PrintWriter getLog() {
		return Memory.log;
	}

	public int getSlidingWindowEnd() {
		return this.slidingWindowEnd;
	}

	// join 2 pivots
	public void pivotJoin(Pivot p1, Pivot p2) {

	}

	public float getRange() {
		return range;
	}

}
