package org.cse.cuhk.stream.application;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Enumeration;
import java.util.Properties;

import org.cse.cuhk.stream.StreamConstants;

import junit.framework.TestCase;

public class testDWT extends TestCase {

	/*
	 * Test method for
	 * 'org.cse.cuhk.stream.application.Memory.getCoefficients(float[])'
	 */
	public void testGetCoefficients() {
		
		Properties props = new Properties();
		try {
			/**
			 * read the property files
			 */
			FileInputStream fis = new FileInputStream(
					StreamConstants.SYSTEM_PROPERTIES);
			props.load(fis);
			fis.close();
		} catch (FileNotFoundException e) {
			// Ignore file not found.
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		/**
		 * Push all loaded properties into System
		 */
		for (Enumeration e = props.propertyNames(); e.hasMoreElements();) {
			String name = (String) e.nextElement();
			System.setProperty(name, (String) props.getProperty(name));
		}
		//int bufferSize = 100000;
		
		String dest = "movement.dat";
		
		int subsequenceLength = Integer.parseInt(System
					.getProperty("SubsequenceLength"));
		
		//int slidingWindowLength = Integer.parseInt(System
		//		.getProperty("SlidingWindowSize"));
		
		int dim = 8;
		
		Memory.dataFile = dest;
		Memory.loadData();
		
		Memory.initializeDWT(dim, 2000);
		
		float dist = Memory.distance_Lp_2(200, 1000);
		float dist_LB = Memory.distance_Lp_2_DWT(
				200, 1000);
		System.out.println("LB " + dist_LB);
		System.out.println("dist " + dist);
	}
	
	public static float distance_Lp_2_DWT(float[] data_1, float[] data_2) {
	
		float D[] = new float[data_1.length];
		for (int i = 0; i < D.length; i++)
			D[i] = data_1[i] - data_2[i];
		float square = D[0]*D[0];
		int current = 1;
		while (current < data_1.length) {
			int start = current;
			int end = 2*current - 1;
			/**
			 * it the value is not padded
			 */
			if (end < data_1.length) {
				for (int j = start; j <= end; j++)
					square += D[j] * D[j];
			}
			square *= 2;
			current *= 2;
		}
		return (float)Math.sqrt((double)square);
	}
}
